        // Wait for document to load
        $(document).ready(() => {
            $('#logform').on('submit', () => {

                // prevents default behaviour
                // Prevents event propagation
                return false;
            });
        });
        $('#logform').keypress((e) => {

            // Enter key corresponds to number 13
            if (e.which === 13) {
                $('#logform').submit();
                console.log('form submitted');
            }
        })


        $(document).on('click', '#login-button', function() {

            if ($('#username').val() != '' && $('#password').val() != '' && $('#type').val() != '') {

                var imgs = '<img src="assets/images/ajax-loader.gif" style="height: 20px; width: 20px;"/>';
                $('#login-button').html(imgs + ' Loading...');
                $('#myalert').slideUp();
                $('#myalert3').slideUp();
                var logform = $('#logform').serialize();
                setTimeout(function() {
                    $.ajax({
                        method: 'POST',
                        url: 'config/init/login_user.php',
                        data: logform,
                        success: function(data) {
                            if (data == 1) {

                                $('#myalert3').slideDown();
                                $('#alerttext3').html(data);
                                $('#alerttext3').html('<i class="fa fa-check"></i> Login Successful. User Verified!');
                                $('#login-button').text('Login');
                                $('#logform')[0].reset();
                                $('#myalert').hide();
                                $('#alerttext').hide();
                                $('#myalert2').hide();
                                $('#alerttext2').hide();
                                setTimeout(function() {
                                    window.location = '/DailyTimeRecords/admin-dashboard/home';
                                }, 1000);
                            } else if (data == 2) {
                                $('#myalert3').slideDown();
                                $('#alerttext3').html(data);
                                $('#alerttext3').html('<i class="fa fa-check"></i> Login Successful. User Verified!');
                                $('#login-button').text('Login');
                                $('#logform')[0].reset();
                                $('#myalert').hide();
                                $('#alerttext').hide();
                                $('#myalert2').hide();
                                $('#alerttext2').hide();
                                setTimeout(function() {
                                window.location = '/DailyTimeRecords/employee-dashboard/home';
                              }, 1000);
                            } else {
                                $('#myalert').slideDown();
                                $('#alerttext').html(data);
                                $('#logtext').text('Login');
                                $('#logform')[0].reset();
                                $('#myalert2').hide();
                                $('#alerttext3').hide();

                            }
                        }
                    });
                }, 1000);
            } else {
                $('#myalert2').slideDown();
                $('#myalert').hide();
                $('#alerttext3').hide();
                $('#myalert2').html('<div class="alert alert-warning err_msg"><i class="fa fa-info"></i> Please input both fields/select to Login</div>');
                $('#logtext').text('Login');
                $('#logform')[0].reset();

            }
        });