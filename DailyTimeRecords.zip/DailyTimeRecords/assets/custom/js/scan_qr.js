       
        function docReady(fn1) {
            if (document.readyState === "complete" ||
                document.readyState === "interactive") {
                setTimeout(fn1, 1);
            } else {
                document.addEventListener("DOMContentLoaded", fn1);
            }
        }
        docReady(function() {
            var resultContainer1 = document.getElementById('reader_a');
            console.log(resultContainer1);
            var lastResult_a, countResults_a = 0;

            function onScanSuccess_a(decodedText_a) {
                if (decodedText_a !== lastResult_a) {
                    ++countResults_a;
                    lastResult_a = decodedText_a;
                    // console.log('================lastResult============');
                    // console.log(lastResult_a);
                    $.ajax({
                        url: 'config/init/qr_process.php',
                        method: 'POST',
                        data: {
                            qr_scan: lastResult_a
                        },
                        success: function(qrdata) {
                            console.log(qrdata);
                            if (qrdata == 1) {
                                swal({
                                    title: 'TIME IN SUCCESSFULLY',
                                    text: 'Thank you for using!!!',
                                    icon: 'success',
                                    timer: 2000,
                                    buttons: false,
                                })
                                setTimeout(function() {
                                    location.reload(1);
                                }, 1000);
                            } else if (qrdata == 2) {
                                swal({
                                    title: 'YOUR QR CODE DOES NOT BELONG (ADMIN GENERAL)',
                                    text: 'Create Account First!!!',
                                    icon: 'error',
                                    timer: 2000,
                                    buttons: false,
                                })
                                setTimeout(function() {
                                    location.reload(1);
                                }, 1000);
                            } else if (qrdata == 3) {
                                swal({
                                    title: 'TIME OUT SUCCESSFULLY',
                                    text: 'Thank you for using!!!',
                                    icon: 'success',
                                    timer: 2000,
                                    buttons: false,
                                })
                                setTimeout(function() {
                                    location.reload(1);
                                }, 1000);
                            } else if (qrdata == 4) {
                                swal({
                                    title: 'ERROR',
                                    text: 'Please try again!!!',
                                    icon: 'success',
                                    timer: 2000,
                                    buttons: false,
                                })
                                setTimeout(function() {
                                    location.reload(1);
                                }, 1000);
                            }
                        }
                    })
                }
            }

            function onScanError_a(errorMessage_1) {
                // handle on error condition, with error message
            }

            var html5QrcodeScanner1 = new Html5QrcodeScanner(
                "reader_a", {
                    fps: 10,
                    qrbox: 250
                });
            html5QrcodeScanner1.render(onScanSuccess_a, onScanError_a);
        });
