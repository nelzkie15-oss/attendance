<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="assets/datatable/css/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="assets/datatable/jquery.min.js"></script>
    <link href="assets/datatable/css/dataTables.bootstrap4.min.css" rel="stylesheet">
    <script src="assets/datatable/js/jquery.dataTables.min.js"></script>
    <script src="assets/datatable/js/dataTables.bootstrap4.min.js"></script>
    <script src="assets/js/sweetalert.min.js"></script>

    <title>Daily Time Records</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,300;0,400;0,500;0,600;1,400;1,500&display=swap');
    </style>
    <style type="text/css">
        * {
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Poppins', sans-serif;
            font-size: 14px;

        }
        /* Tables */
        table {
            width: 100%;
            margin-bottom: 1em;
            border-collapse: collapse;
        }

        th,
        td {
            padding: 0.2em;
            border: 1px solid #ccc;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light btn-light" style="border-bottom: 2px solid #7c0040;background-color: #29c273 !important;color: #fff">
        <div class="container">
            <a class="navbar-brand" href="#" style="color: #fff"> <img src="assets/images/clock.png" height="6%" width="6%"> Daily Time Records</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="member-login" style="font-size:1.2rem;color: #fff"><i class="fa fa-sign-in"></i> login</a>
                </li>
            </ul>
        </div>
    </nav>

    <div class="container">
        <div class="card mt-4" style="background-color: #68d979;color: #fff">
            <div class="card-body">
               This dtr is used every day for the employee who just enters.
            </div>
        </div>

        <div class="container-fluid px-lg-5 mt-4">
            <div class="row justify-content-md-center">
                <div class="col col-lg-5">
                    <center>
                    </center>
                    <div style="width: 100%" id="reader_a"></div>
                </div>
                <div class="col col-lg-7 ">
                    <center>
                      <div class="table-responsive">
                        <table class="table table-bordered" id="dataTable_1">
                            <thead>
                                <tr>
                                    <th scope="col">PHOTO</th>
                                    <th scope="col">EMPLOYEE ID NO.</th>
                                    <th scope="col">TIME IN</th>
                                    <th scope="col">TIME OUT</th>
                                    <th scope="col">LOG DATE</th>
                                </tr>
                            </thead>
                            <tbody>
                                  <?php 
                                     include('config/DTR_class.php');
                                     $conn = new Attendance();
                                     $dtr = $conn->FetchAttendance();
                                  ?>
                                  <?php foreach ($dtr as $row) {
                                       $pic = htmlentities($row['images']);
                                       $image = substr($pic,3) ? substr($pic,3) :"images/191688-200.png";//sets your image

                                   ?>
                                  <tr align="center">
                                        <td>
                                            <center><img src="<?php echo $image;?>" width="50px;" height="50px"></center>
                                        </td>
                                        <td><?= htmlentities($row['empid_no']); ?></td>
                                        <td><?= date("g:i a", strtotime(htmlentities($row['time_in']))); ?></td>
                                        <td>
                                           <?php if (empty(htmlentities($row['time_out']))) {
                                              echo "";
                                             }else{
                                                echo date("g:i a", strtotime(htmlentities($row['time_out'])));
                                             }

                                            ?></td>
                                        <td><?= htmlentities(date("M d, Y",strtotime($row['logdate']))); ?></td>
                                    </tr>
                                 <?php } ?>
                            </tbody>
                        </table>
                        </div>
                    </center>
                   </div>
                </div>
            </div>
        </div>
    </div>
    <script src="assets/custom/js/html5-qrcode.min.js"></script>
    <script type="text/javascript" src="assets/custom/js/scan_qr.js"></script>
    <script type="text/javascript" src="assets/custom/js/mdb.min.js"></script>
    <script>
     

        $(document).ready(function() {
    $('#dataTable_1').dataTable( {
        "lengthMenu": [5, 10, 20, 40, 60, 80, 100],
        "pageLength": 5
    } );
} );

    </script>
      <script type="text/javascript">
      document.oncontextmenu = document.body.oncontextmenu = function() {return false;}//disable right click


      $(document).keydown(function (event) {
        if (event.keyCode == 123) { // Prevent F12
            return false;
        } else if (event.ctrlKey && event.shiftKey && event.keyCode == 73) { // Prevent Ctrl+Shift+I        
            return false;
        }
    });
    </script>
    <script src="assets/datatable/js/bootstrap.bundle.min.js" integrity="sha384-Fy6S3B9q64WdZWQUiU+q4/2Lc9npb8tCaSX9FK7E8HnRr0Jz8D6OP9dO5Vg3Q9ct" crossorigin="anonymous"></script>

</body>

</html>