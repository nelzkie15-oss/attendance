<!doctype html>
<html lang="en">

<head>
     <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="assets/datatable/css/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="assets/datatable/jquery.min.js"></script>
    <link href="assets/datatable/css/dataTables.bootstrap4.min.css" rel="stylesheet">
    <script src="assets/datatable/js/jquery.dataTables.min.js"></script>
    <script src="assets/datatable/js/dataTables.bootstrap4.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <title>Daily Time Records</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,300;0,400;0,500;0,600;1,400;1,500&display=swap');
    </style>
    <style type="text/css">
        * {
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Poppins', sans-serif;
            font-size: 14px;

        }
        /* Tables */
        table {
            width: 100%;
            margin-bottom: 1em;
            border-collapse: collapse;
        }

        th,
        td {
            padding: 0.2em;
            border: 1px solid #ccc;
        }
    </style>
</head>

<body>

    <nav class="navbar navbar-expand-lg navbar-light btn-light" style="border-bottom: 2px solid #7c0040;background-color: #29c273 !important;color: #fff">
        <div class="container">
            <a class="navbar-brand" href="#" style="color: #fff"> <img src="assets/images/clock.png" height="6%" width="6%"> Daily Time Records</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="index" style="font-size:1.2rem;color: #fff"><i class="fa fa-home"></i> home</a>
                </li>
            </ul>

        </div>
    </nav>

    <div class="container">

        <div class="container-fluid px-lg-5" style="margin-top: 10%">
            <div class="row justify-content-md-center">
                <div class="col col-lg-5">
               
                    <div class="login-box">
                        <div class="card" style="border-top: 3px solid green">
                            <div class="card-header text-center" style="font-weight: bold;">
                                LOGIN HERE</h3>
                            </div>
                            <div class="card-body">
                                <form role="form" id="logform">
                                    <div class="">
                                        <center><span id="myalert2"></span></center>
                                    </div>
                                    <div id="myalert" style="display:none;">

                                        <div class="">
                                           <center><span id="alerttext"></span></center>
                                        </div>

                                    </div>
                                    <div id="myalert3" style="display:none;">
                                        <div class="">
                                            <div class="alert alert-success" id="alerttext3">

                                            </div>

                                        </div>
                                    </div>

                                    <div class="input-group mb-3">
                                        <input type="text" class="form-control btn-lg" name="username" id="username" placeholder="Username" autocomplete="off" required="">
                                        <div class="input-group-append">
                                            <div class="input-group-text">
                                                <span class="fa fa-user"></span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="input-group mb-3">
                                        <input type="password" class="form-control btn-lg" name="password" id="password" placeholder="Password" autocomplete="off" required="">
                                        <div class="input-group-append">
                                            <div class="input-group-text">
                                                <span class="fa fa-lock"></span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="input-group mb-3">
                                        <select id="type" name="type" class="form-control btn-lg">
                                            <option selected>&larr; Please Select User Roles &rarr;</option>
                                            <option value="Administrator">Administrator</option>
                                            <option value="Employee">Employee</option>
                                        </select>
                                    </div>
                                    <div class="row">
                                        <div class="col-8">
                                            <div class="icheck-primary">
                                                <input type="checkbox" id="remember" onclick="myFunction()">
                                                <label for="remember">
                                                    Show Password
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-12 mb-1">
                                            <button type="button" id="login-button" class="btn btn-success btn-lg btn-block">Sign In</button>
                                        </div>
                                    </div>
                                </form>

                                <p class="mb-1">
                                    <a href="forgot-password.php">I forgot my password</a>
                                </p>

                            </div>
                        </div>
                    </div>


                </div>
     
            </div>
        </div>
    </div>
    <script>
        function myFunction() {
            var x = document.getElementById("password");
            if (x.type === "password") {
                x.type = "text";
            } else {
                x.type = "password";
            }
        }
    </script>
      <script type="text/javascript">
      document.oncontextmenu = document.body.oncontextmenu = function() {return false;}//disable right click


      $(document).keydown(function (event) {
        if (event.keyCode == 123) { // Prevent F12
            return false;
        } else if (event.ctrlKey && event.shiftKey && event.keyCode == 73) { // Prevent Ctrl+Shift+I        
            return false;
        }
    });
    </script>
    <script type="text/javascript" src="assets/custom/js/login.js"> </script>
   <script src="assets/datatable/js/bootstrap.bundle.min.js" integrity="sha384-Fy6S3B9q64WdZWQUiU+q4/2Lc9npb8tCaSX9FK7E8HnRr0Jz8D6OP9dO5Vg3Q9ct" crossorigin="anonymous"></script>


</body>

</html>