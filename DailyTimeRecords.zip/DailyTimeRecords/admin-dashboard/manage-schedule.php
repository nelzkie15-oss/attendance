<?php include 'headerANDsidebar/menu.php';?>

<main id="main" class="main">

    <div class="card">
        <div class="card-body">
            <nav>
                <ol class="breadcrumb pt-4">
                    <li class="breadcrumb-item"><a href="home"><i class="bi bi-house-door"></i> Home</a></li>
                    <li class="breadcrumb-item active"><i class="bi bi-clock"></i> Manage Schedule</li>
                </ol>
            </nav>
        </div>
    </div>
  <div id="loader"></div>
    <section class="section dashboard">
        <div class="row">
            <div class="col-md-12">
                <div class="card recent-sales overflow-auto">

                    <div class="card-body">
                        <div class="row">
                            <div class="col-4">
                                <h5 class="card-title">Manage Schedule</h5>
                            </div>
                            <div class="col-8"><button class="btn btn-outline-success mt-3" style="float: right;" value="Add Schedule" data-bs-toggle="modal" data-bs-target="#schedule-modal"><i class="bi bi-plus-circle"></i> Add Schedule</button></div>
                        </div>
                        <hr style="border:2px solid black">
                        </hr>
                       <div class="table-responsive">
                        <table class="table table-striped datatable">
                            <thead>
                                <tr>
                                    <th scope="col">Employee Name</th>
                                    <th scope="col">Schedule From</th>
                                    <th scope="col">Schedule To</th>
                                    <th scope="col">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($FSchedule as $row) { ?>

                                <tr>
                                  <td><?= htmlentities($row['employee_name']); ?></td>
                                  <td><?php echo date("g:i a", strtotime(htmlentities($row['sched_from']))); ?></td>
                                  <td><?php echo date("g:i a", strtotime(htmlentities($row['sched_to']))); ?></td>
                                  <td width="14%"> <center><button class="btn btn-outline-primary btn-sm btn-edit" data-edit="<?= htmlentities($row['schedule_id']); ?>"><i class="bi bi-plus-edit"></i> Edit</button> <button class="btn btn-outline-danger btn-sm btn-del" data-del="<?= htmlentities($row['schedule_id']); ?>"><i class="bi bi-plus-trash"></i> Delete</button> </center></td>
                                </tr>
                               <?php } ?>
                            </tbody>
                        </table>
                      </div>
                    </div>
                </div>
            </div><!-- End Recent Sales -->

        </div>
        </div>
        </div>
    </section>

</main>
<?php include 'modal/Add_schedule_modal.php';?>
<?php include 'modal/Edit_schedule_modal.php';?>
<?php include 'modal/Delete_schedule_modal.php';?>
<?php include 'footer/footer.php';?>
  <script>
           $(document).ready(function() {   
               load_data();    
               var count = 1; 
               function load_data() {
                   $(document).on('click', '.btn-edit', function() {
                        $('#editschedule-modal').modal('show');
                        var schedule_id = $(this).data("edit");
                         // console.log(department_id);
                          getID(schedule_id); //argument    
                 
                   });
                }

                 function getID(schedule_id) {
                      $.ajax({
                          type: 'POST',
                          url: '../config/init/row_schedule.php',
                          data: {
                              schedule_id: schedule_id
                          },
                          dataType: 'json',
                          success: function(response) {
 
                          $('#edit_scheduleid').val(response.schedule_id);
                          $('#edit_empid').val(response.emp_id);
                          $('#edit_schedfrom').val(response.sched_from);
                          $('#edit_schedto').val(response.sched_to);
      
                       }
                    });
                 }
           
           });
            
     </script>
       <script>
       $(document).ready(function() {   
           load_data();    
           var count = 1; 
           function load_data() {
               $(document).on('click', '.btn-del', function() {
                  $('#delschedule-modal').modal('show');
                    var schedule_id = $(this).data("del");
                      get_delId(schedule_id); //argument    
             
               });
            }

             function get_delId(schedule_id) {
                  $.ajax({
                      type: 'POST',
                      url: '../config/init/row_schedule.php',
                      data: {
                          schedule_id: schedule_id
                      },
                      dataType: 'json',
                      success: function(response2) {
                      $('#delete_scheduleid').val(response2.schedule_id);
                      $('#delete_empid').val(response2.emp_id);
      
                   }
                });
             }
       
       });
        
 </script>
</body>

</html>