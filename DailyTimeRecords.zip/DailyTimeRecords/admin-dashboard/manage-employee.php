<?php include 'headerANDsidebar/menu.php';?>
<main id="main" class="main">
    <div class="card">
        <div class="card-body">
            <nav>
                <ol class="breadcrumb pt-4">
                    <li class="breadcrumb-item"><a href="home"><i class="bi bi-house-door"></i> Home</a></li>
                    <li class="breadcrumb-item active"><i class="bi bi-person"></i> Manage Employee</li>
                </ol>
            </nav>
        </div>
    </div>
  <div id="loader"></div>
    <section class="section dashboard">
        <!-- Recent Sales -->
        <div class="row">
            <div class="col-md-12">
                <div class="card recent-sales overflow-auto">

                    <div class="card-body">
                        <div class="row">
                            <div class="col-4">
                                <h5 class="card-title">Manage Employee</h5>
                            </div>
                            <div class="col-8"><button class="btn btn-outline-success mt-3" style="float: right;" value="Add Employee" data-bs-toggle="modal" data-bs-target="#employee-modal"><i class="bi bi-plus-circle"></i> Add Employee</button></div>
                        </div>
                        <hr style="border:2px solid black">
                        </hr>

                       <div class="table-responsive">
                        <table class="table table-striped datatable">
                            <thead>
                                <tr>
                                    <th scope="col">Photo</th>
                                    <th scope="col">QR image</th>
                                    <th scope="col">Employee ID No.</th>
                                    <th scope="col">Employee Name</th>
                                    <th scope="col">Contact #</th>
                                    <th scope="col">Daily Rate</th>
                                    <th scope="col">Monthly Rate</th>
                                    <th scope="col">Status</th>
                                    <th scope="col">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                             <?php foreach ($FEmps as $row) {
                                 $pic = htmlentities($row['images']);
                                 $image = $pic ? $pic :"../uploads/default_img/191688-200.png";//sets your image
                              ?>
                                <tr>
                                 <td><center><img src="<?php echo $image;?>" width="50px" height="50px" ></center></td>
                                 <td><center><a href="../qrcode_images/<?= $row['empid_no']; ?>.png" title="click QR Code Image if you want to download" download/> <img src="../qrcode_images/<?= $row['empid_no']; ?>.png" width="50px" height="50px"></a></center></td>
                                 <td><?= htmlentities($row['empid_no']); ?></td>
                                 <td><?= htmlentities($row['employee_name']); ?></td>
                                 <td><?= htmlentities($row['contact_number']); ?></td>
                                 <td><?= htmlentities($row['daily_rate']); ?></td>
                                 <td><?= htmlentities(number_format($row['mothly_rate'],2)); ?></td>
                                <td>
                                 <?php if(htmlentities($row['status']) == 'Active'){
                                    echo '<span class="badge bg-success"><i class="bi bi-check-circle me-1"></i> Active</span>';
                                  }else{
                                    echo '<span class="badge bg-danger"><i class="bi bi-exclamation-octagon me-1"></i> Inactive</span>';
                                 } ?>
                                </td>
                                 <td width="20%"> <center><button class="btn btn-outline-info btn-sm btn_views" data-views="<?= htmlentities($row['emp_id']); ?>"><i class="bi bi-plus-eye"></i> View</button>  <button class="btn btn-outline-primary btn-sm btn-edit" data-edit="<?= htmlentities($row['emp_id']); ?>"><i class="bi bi-plus-edit"></i> Edit</button> <button class="btn btn-outline-danger btn-sm btn-del" data-del="<?= htmlentities($row['emp_id']); ?>"><i class="bi bi-plus-trash"></i> Delete</button> </center></td>
                                </tr>
                               <?php } ?>
                            </tbody>
                        </table>
                      </div>
                    </div>
                </div>
            </div><!-- End Recent Sales -->

        </div>
        </div>
        </div>
    </section>

</main>
<?php include 'modal/Add_employee_modal.php';?>
<?php include 'modal/View_employee_modal.php';?>
<?php include 'modal/Edit_employee_modal.php';?>
<?php include 'modal/Delete_employee_modal.php';?>
<?php include 'footer/footer.php';?>
  <script>
           $(document).ready(function() {   
               load_data();    
               var count = 1; 
               function load_data() {
                   $(document).on('click', '.btn_views', function() {
                        $('#viewemployee-modal').modal('show');
                        var emp_id = $(this).data("views");
                         // console.log(department_id);
                          getID(emp_id); //argument    
                 
                   });
                }

                 function getID(emp_id) {
                      $.ajax({
                          type: 'POST',
                          url: '../config/init/row_employee.php',
                          data: {
                              emp_id: emp_id
                          },
                          dataType: 'json',
                          success: function(response) {
 
                          $('#view_empid').val(response.emp_id);
                          $('#view_images').attr("src",response.images.slice(0));//image
                          $('#view_empidno').val(response.empid_no);
                          $('#view_firstname').val(response.first_name);
                          $('#view_middlename').val(response.middle_name);
                          $('#view_lastname').val(response.last_name);
                          $('#view_dateofbirth').val(response.date_ofbirth);
                          $('#view_contactnumber').val(response.contact_number);
                          $('#view_completeaddress').val(response.complete_address);
                          $('#view_gender').val(response.gender);
                          $('#view_email').val(response.email);
                          $('#view_dailyrate').val(response.daily_rate);
                          $('#view_mothlyrate').val(response.mothly_rate);
                          $('#view_sssno').val(response.sss_no);
                          $('#view_philHealth').val(response.philHealth);
                          $('#view_pagibig').val(response.pag_ibig);
                          $('#view_designation').val(response.designation);
                          $('#view_departmentid').val(response.department_id);
                          $('#view_datehire').val(response.date_hire);
                          $('#view_username').val(response.username);
                          $('#view_password').val(response.password);
                          $('#view_empstatus').val(response.emp_status);
                          $('#view_qrcode').val(response.qr_code);
                          $('#view_status').val(response.status);
                          $('#view_type').val(response.type);
      
                       }
                    });
                 }
           
           });
            
     </script>

       <script>
           $(document).ready(function() {   
               load_data();    
               var count = 1; 
               function load_data() {
                   $(document).on('click', '.btn-edit', function() {
                        $('#editemployee-modal').modal('show');
                        var emp_id = $(this).data("edit");
                         // console.log(department_id);
                          getID(emp_id); //argument    
                 
                   });
                }

                 function getID(emp_id) {
                      $.ajax({
                          type: 'POST',
                          url: '../config/init/row_employee.php',
                          data: {
                              emp_id: emp_id
                          },
                          dataType: 'json',
                          success: function(response1) {


                          $('#edit_empid').val(response1.emp_id);
                          $('#edit_images').attr("src",response1.images.slice(0));//image
                          $('#edit_empidno').val(response1.empid_no);
                          $('#edit_firstname').val(response1.first_name);
                          $('#edit_middlename').val(response1.middle_name);
                          $('#edit_lastname').val(response1.last_name);
                          $('#edit_dateofbirth').val(response1.date_ofbirth);
                          $('#edit_contactnumber').val(response1.contact_number);
                          $('#edit_completeaddress').val(response1.complete_address);
                          $('#edit_gender').val(response1.gender);
                          $('#edit_email').val(response1.email);
                          $('#edit_dailyrate').val(response1.daily_rate);
                          $('#edit_mothlyrate').val(response1.mothly_rate);
                          $('#edit_sssno').val(response1.sss_no);
                          $('#edit_philHealth').val(response1.philHealth);
                          $('#edit_pagibig').val(response1.pag_ibig);
                          $('#edit_designation').val(response1.designation);
                          $('#edit_departmentid').val(response1.department_id);
                          $('#edit_datehire').val(response1.date_hire);
                          $('#edit_username').val(response1.username);
                          $('#edit_password').val(response1.password);
                          $('#edit_empstatus').val(response1.emp_status);
                          $('#edit_qrcode').val(response1.qr_code);
                          $('#edit_status').val(response1.status);
                          $('#edit_type').val(response1.type);
                          

      
                       }
                    });
                 }
           
           });
            
     </script>
       <script>
       $(document).ready(function() {   
           load_data();    
           var count = 1; 
           function load_data() {
               $(document).on('click', '.btn-del', function() {
                  $('#delemployee-modal').modal('show');
                    var emp_id = $(this).data("del");
                      get_delId(emp_id); //argument    
             
               });
            }

             function get_delId(emp_id) {
                  $.ajax({
                      type: 'POST',
                      url: '../config/init/row_employee.php',
                      data: {
                          emp_id: emp_id
                      },
                      dataType: 'json',
                      success: function(response2) {
                      $('#delete_empid').val(response2.emp_id);
                      $('#delete_empidno').val(response2.empid_no);
      
                   }
                });
             }
       
       });
        
 </script>
   <script type="text/javascript">
        function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function(e) {
                    var num = $(input).attr('class').split('-')[2];
                    $('.file-uploader .preview-' + num).attr('src', e.target.result);
                }

                reader.readAsDataURL(input.files[0]);
            }
        }

        $("[class^=upload-field-]").change(function() {
            readURL(this);
        });
    </script>
</body>

</html>