<div class="modal" id="editemployee-modal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content ">
            <div class="modal-header">
                <h5 class="modal-title"><i class="bi bi-plus-circle"></i> Edit Employee</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">

                <div class="row">
                    <div class="col-lg-3 mt-2">
                        <div class="form-group">
                            <label for="inputTime"><b>Employee ID No.:</b></label>
                            <input type="text" id="edit_empidno" class="form-control" autocomplete="off">
                            <span class="empno-error"></span>
                        </div>
                    </div>
                    <div class="col-lg-3 mt-2">
                        <div class="form-group">
                            <label for="inputTime"><b>First Name:</b></label>
                            <input type="text" id="edit_firstname" class="form-control" autocomplete="off">
                            <span class="fname-error"></span>
                        </div>
                    </div>
                    <div class="col-lg-3 mt-2">
                        <div class="form-group">
                            <label for="inputTime"><b>Middle Name:</b></label>
                            <input type="text" id="edit_middlename" class="form-control" placeholder="(Optionnal)" autocomplete="off">
                            <span class=""></span>
                        </div>
                    </div>
                    <div class="col-lg-3 mt-2">
                        <div class="form-group">
                            <label for="inputTime"><b>Last Name: </b></label>
                            <input type="text" id="edit_lastname" class="form-control" autocomplete="off">
                            <span class="lname-error"></span>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-lg-3 mt-2">
                        <div class="form-group">
                            <label for="inputTime"><b>Date of Birth:</b></label>
                            <input type="date"  id="edit_dateofbirth" class="form-control" autocomplete="off">
                            <span class="dbirth-error"></span>
                        </div>
                    </div>
                    <div class="col-lg-3 mt-2">
                        <div class="form-group">
                            <label for="inputTime"><b>Contact Number:</b></label>
                            <input type="text" id="edit_contactnumber" class="form-control" minlength="11" maxlength="11" autocomplete="off">
                            <span class="cnumber-error"></span>
                        </div>
                    </div>
                    <div class="col-lg-6 mt-2">
                        <div class="form-group">
                            <label for="inputTime"><b>Complete Address: </b></label>
                            <input type="text" id="edit_completeaddress" class="form-control" autocomplete="off">
                            <span class="caddress-error"></span>
                        </div>
                    </div>
                </div>


                <div class="row">
                    <div class="col-lg-3 mt-2">
                        <div class="form-group">
                            <label for="inputTime"><b>Gender: </b></label>
                            <select class="form-control" id="edit_gender"  autocomplete="off">
                                <option value="">&larr; Select Gender &rarr;</option>
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                            </select>
                            <span class="gen-error"></span>
                        </div>
                    </div>
                    <div class="col-lg-3 mt-2">
                        <div class="form-group">
                            <label for="inputTime"><b>Email: </b></label>
                            <input type="email" id="edit_email" class="form-control" placeholder="(Optionnal)" autocomplete="off">
                            <span class=""></span>
                        </div>
                    </div>
                    <div class="col-lg-3 mt-2">
                        <div class="form-group">
                            <label for="inputTime"><b>Daily Rate:</b></label>
                            <input type="text" id="edit_dailyrate" class="form-control" autocomplete="off">
                            <span class="drate-error"></span>
                        </div>
                    </div>
                    <div class="col-lg-3 mt-2">
                        <div class="form-group">
                            <label for="inputTime"><b>Monthly Rate:</b></label>
                            <input type="text" id="edit_mothlyrate" class="form-control" autocomplete="off">
                            <span class="mrate-error"></span>
                        </div>
                    </div>

                </div>

                <div class="row">
                    <div class="col-lg-4 mt-2">
                        <div class="form-group">
                            <label for="inputTime"><b>SSS #: </b></label>
                            <input type="text" id="edit_sssno" class="form-control" autocomplete="off">
                            <span class="sssno-error"></span>
                        </div>
                    </div>
                    <div class="col-lg-4 mt-2">
                        <div class="form-group">
                            <label for="inputTime"><b>PhilHealth #:</b></label>
                            <input type="text" id="edit_philHealth" class="form-control" autocomplete="off">
                            <span class="phil-error"></span>
                        </div>
                    </div>
                    <div class="col-lg-4 mt-2">
                        <div class="form-group">
                            <label for="inputTime"><b>Pag-ibig #:</b></label>
                            <input type="text" id="edit_pagibig" class="form-control" autocomplete="off">
                            <span class="ibig-error"></span>
                        </div>
                    </div>

                </div>
                <div class="row">
                    <div class="col-lg-4 mt-2">
                        <div class="form-group">
                            <label for="inputTime"><b>Designation: </b></label>
                            <input type="text" id="edit_designation" class="form-control" autocomplete="off">
                            <span class="desig-error"></span>
                        </div>
                    </div>
                    <div class="col-lg-4 mt-2">
                        <div class="form-group">
                            <label for="inputTime"><b>Department: </b></label>
                            <select class="form-control" id="edit_departmentid"  autocomplete="off">
                                <option value="">&larr; Select Department &rarr;</option>
                                <?php
                                 require_once "../config/DTR_class.php";
                                  $conn = new Attendance();
                                  $depts = $conn->FetchDepartment();
                                 foreach ($depts as $row) { ?>
                                  <option value="<?php echo htmlentities($row['department_id']); ?>"><?php echo htmlentities($row['department_name']); ?></option>
                                <?php } ?>
                            </select>
                            <span class="dept-error"></span>
                        </div>
                    </div>
                    <div class="col-lg-4 mt-2">
                        <div class="form-group">
                            <label for="inputTime"><b>Date Hire:</b></label>
                            <input type="date" id="edit_datehire" class="form-control" autocomplete="off">
                            <span class="dhire-error"></span>
                        </div>
                    </div>

                </div>

                <div class="row">
                    <div class="col-lg-4 mt-2">
                        <div class="form-group">
                            <label for="inputTime"><b>Username: </b></label>
                            <input type="text" id="edit_username" class="form-control" autocomplete="off">
                            <span class="uname-error"></span>
                        </div>
                    </div>
                    <div class="col-lg-4 mt-2">
                        <div class="form-group">
                            <label for="inputTime"><b>Password:</b></label>
                            <input type="password" id="edit_password" class="form-control" autocomplete="off">
                            <span class="pass-error"></span>
                        </div>
                    </div>

                    <div class="col-lg-4 mt-2">
                        <div class="form-group">
                            <label for="inputTime"><b>Status: </b></label>
                            <select class="form-control" id="edit_empstatus" autocomplete="off" >
                                <option value="">&larr; Select Status &rarr;</option>
                                <option value="Probationary">Probationary</option>
                                <option value="Regular">Regular</option>
                             </select>
                          <span class="dhire-error"></span>
                        </div>
                    </div>
                </div>


            </div>
            <div class="modal-footer">
                <input type="hidden" id="edit_empid" name="">
                <button type="button" class="btn btn-outline-danger" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-outline-primary" id="btn-editemployee">Update</button>
            </div>
        </div>
    </div>
</div>


<script type="text/javascript">
    document.addEventListener('DOMContentLoaded', () => {
        let btn = document.querySelector('#btn-editemployee');
        btn.addEventListener('click', (e) => {
            e.preventDefault();

            const empid_no = document.querySelector('input[id=edit_empidno]').value;
            console.log(empid_no);

            const first_name = document.querySelector('input[id=edit_firstname]').value;
            console.log(first_name);

            const middle_name = document.querySelector('input[id=edit_middlename]').value;
            console.log(middle_name);

            const last_name = document.querySelector('input[id=edit_lastname]').value;
            console.log(last_name);

            const date_ofbirth = document.querySelector('input[id=edit_dateofbirth]').value;
            console.log(date_ofbirth);

            const contact_number = document.querySelector('input[id=edit_contactnumber]').value;
            console.log(contact_number);

            const complete_address = document.querySelector('input[id=edit_completeaddress]').value;
            console.log(complete_address);

            const gender = $('#edit_gender option:selected').val();
            console.log(gender);

            const email = document.querySelector('input[id=edit_email]').value;
            console.log(email);

            const daily_rate = document.querySelector('input[id=edit_dailyrate]').value;
            console.log(daily_rate);

            const mothly_rate = document.querySelector('input[id=edit_mothlyrate]').value;
            console.log(mothly_rate);

            const sss_no = document.querySelector('input[id=edit_sssno]').value;
            console.log(sss_no);

            const philHealth = document.querySelector('input[id=edit_philHealth]').value;
            console.log(philHealth);

            const pag_ibig = document.querySelector('input[id=edit_pagibig]').value;
            console.log(pag_ibig);

            const designation = document.querySelector('input[id=edit_designation]').value;
            console.log(designation);

            const department_id = $('#edit_departmentid option:selected').val();
            console.log(department_id);

            const date_hire = document.querySelector('input[id=edit_datehire]').value;
            console.log(date_hire);

           const username = document.querySelector('input[id=edit_username]').value;
            console.log(username);

            const password = document.querySelector('input[id=edit_password]').value;
            console.log(password);

            const emp_status = $('#edit_empstatus option:selected').val();
            console.log(emp_status);

            const emp_id = document.querySelector('input[id=edit_empid]').value;
            console.log(emp_id);

            var data = new FormData(this.form);


            data.append('empid_no', empid_no);
            data.append('first_name', first_name);
            data.append('middle_name', middle_name);
            data.append('last_name', last_name);
            data.append('date_ofbirth', date_ofbirth);
            data.append('contact_number', contact_number);
            data.append('complete_address', complete_address);
            data.append('gender', gender);
            data.append('email', email);
            data.append('daily_rate', daily_rate);
            data.append('mothly_rate', mothly_rate);
            data.append('sss_no', sss_no);
            data.append('philHealth', philHealth);
            data.append('pag_ibig', pag_ibig);
            data.append('designation', designation);
            data.append('department_id', department_id);
            data.append('date_hire', date_hire);
            data.append('username', username);
            data.append('password', password);
            data.append('emp_status', emp_status);
            data.append('emp_id', emp_id);


            function isValidEmpIDNo2() {
                var pattern = /^[a-zA-Z 0-9\s]+$/;
                var empid_no = $("#edit_empidno").val();
                if (pattern.test(empid_no) && empid_no !== "") {
                    $("#edit_empidno").removeClass("is-invalid").addClass("is-valid");
                    $(".empno-error").css({
                        "color": "green",
                        "font-size": "14px",
                        "display": "none"
                    });
                    return true;
                } else if (empid_no === "") {
                    $("#edit_empidno").removeClass("is-valid").addClass("is-invalid");
                    $(".empno-error").html('Required Employee ID No.');
                    $(".empno-error").css({
                        "color": "red",
                        "font-size": "14px"
                    });
                } else {
                    $("#edit_empidno").removeClass("is-valid").addClass("is-invalid");
                    $(".empno-error").html('Please input Character/Number');
                    $(".empno-error").css({
                        "color": "red",
                        "font-size": "14px",
                        "display": "block"
                    });
                }
            };


            function isValidFName2() {
                var pattern = /^[a-zA-Z \s]+$/;
                var first_name = $("#edit_firstname").val();
                if (pattern.test(first_name) && first_name !== "") {
                    $("#edit_firstname").removeClass("is-invalid").addClass("is-valid");
                    $(".fname-error").css({
                        "color": "green",
                        "font-size": "14px",
                        "display": "none"
                    });
                    return true;
                } else if (first_name === "") {
                    $("#edit_firstname").removeClass("is-valid").addClass("is-invalid");
                    $(".fname-error").html('Required First Name');
                    $(".fname-error").css({
                        "color": "red",
                        "font-size": "14px"
                    });
                } else {
                    $("#edit_firstname").removeClass("is-valid").addClass("is-invalid");
                    $(".fname-error").html('Please input Character only');
                    $(".fname-error").css({
                        "color": "red",
                        "font-size": "14px",
                        "display": "block"
                    });
                }
            };



           function isValidMname2() {
                if ($("#edit_middlename").val() === "" && $("#edit_middlename").val()) {
                    $("#edit_middlename").removeClass("is-invalid").addClass("is-valid");
                    return false;
                } else {
                    $("#edit_middlename").removeClass("is-invalid").addClass("is-valid");
                    return true;
                }
            };


            function isValidLname2() {
                var pattern = /^[a-zA-Z \s]+$/;
                var last_name = $("#edit_lastname").val();
                if (pattern.test(last_name) && last_name !== "") {
                    $("#edit_lastname").removeClass("is-invalid").addClass("is-valid");
                    $(".lname-error").css({
                        "color": "green",
                        "font-size": "14px",
                        "display": "none"
                    });
                    return true;
                } else if (last_name === "") {
                    $("#edit_lastname").removeClass("is-valid").addClass("is-invalid");
                    $(".lname-error").html('Required Last Name');
                    $(".lname-error").css({
                        "color": "red",
                        "font-size": "14px"
                    });
                } else {
                    $("#edit_lastname").removeClass("is-valid").addClass("is-invalid");
                    $(".lname-error").html('Please input Character only');
                    $(".lname-error").css({
                        "color": "red",
                        "font-size": "14px",
                        "display": "block"
                    });
                }
            };

            function isValidDbirth2() {
                if ($("#edit_dateofbirth").val() === "") {
                    $("#edit_dateofbirth").addClass("is-invalid");
                    $(".dbirth-error").html('Required Date of Birth');
                    $(".dbirth-error").css({
                        "color": "red",
                        "font-size": "14px",
                    });
                    return false;
                } else {
                    $("#edit_dateofbirth").removeClass("is-invalid").addClass("is-valid");
                     $(".dbirth-error").css({
                        "display": "none"
                    });
                    return true;
                }
            };


            function isValiCnumber2() {
                var pattern = /^[0-9]{11}$/;
                var contact_number = $("#edit_contactnumber").val();
                if (pattern.test(contact_number) && contact_number !== "") {
                    $("#edit_contactnumber").removeClass("is-invalid").addClass("is-valid");
                    $(".cnumber-error").css({
                        "color": "green",
                        "font-size": "14px",
                        "display": "none"
                    });
                    return true;
                } else if (contact_number === "") {
                    $("#edit_contactnumber").removeClass("is-valid").addClass("is-invalid");
                    $(".cnumber-error").html('Required Contact Number');
                    $(".cnumber-error").css({
                        "color": "red",
                        "font-size": "14px"
                    });
                } else {
                    $("#edit_contactnumber").removeClass("is-valid").addClass("is-invalid");
                    $(".cnumber-error").html('Please input Number only');
                    $(".cnumber-error").css({
                        "color": "red",
                        "font-size": "14px",
                        "display": "block"
                    });
                }
            };

           function isValiCAddress2() {
                var pattern = /^[a-zA-Z0-9 !_@#$%^&-*].*$/;
                var complete_address = $("#edit_completeaddress").val();
                if (pattern.test(complete_address) && complete_address !== "") {
                    $("#edit_completeaddress").removeClass("is-invalid").addClass("is-valid");
                    $(".caddress-error").css({
                        "color": "green",
                        "font-size": "14px",
                        "display": "none"
                    });
                    return true;
                } else if (complete_address === "") {
                    $("#edit_completeaddress").removeClass("is-valid").addClass("is-invalid");
                    $(".caddress-error").html('Required Complete Address');
                    $(".caddress-error").css({
                        "color": "red",
                        "font-size": "14px"
                    });
                } else {
                    $("#edit_completeaddress").removeClass("is-valid").addClass("is-invalid");
                    $(".caddress-error").html('Please input Character/Number');
                    $(".caddress-error").css({
                        "color": "red",
                        "font-size": "14px",
                        "display": "block"
                    });
                }
            };


            function isValidGender2() {
                if ($("#edit_gender").val() === "") {
                    $("#edit_gender").addClass("is-invalid");
                    $(".gen-error").html('Required Gender');
                    $(".gen-error").css({
                        "color": "red",
                        "font-size": "14px",
                    });
                    return false;
                } else {
                    $("#edit_gender").removeClass("is-invalid").addClass("is-valid");
                     $(".gen-error").css({
                        "display": "none"
                    });
                    return true;
                }
            };


            function isValidEmail2() {
                if ($("#edit_email").val() === "" && $("#edit_email").val()) {
                    $("#edit_email").removeClass("is-invalid").addClass("is-valid");
                    return false;
                } else {
                    $("#edit_email").removeClass("is-invalid").addClass("is-valid");
                    return true;
                }
            };

           function isValidDrate2() {
                pattern = /^[0-9.,\s]+$/;
                var daily_rate = $("#edit_dailyrate").val();
                if (pattern.test(daily_rate) && daily_rate !== "") {
                    $("#edit_dailyrate").removeClass("is-invalid").addClass("is-valid");
                    $(".drate-error").css({
                        "color": "green",
                        "font-size": "14px",
                        "display": "none"
                    });
                    return true;
                } else if (daily_rate === "") {
                    $("#edit_dailyrate").removeClass("is-valid").addClass("is-invalid");
                    $(".drate-error").html('Required Daily Rate');
                    $(".drate-error").css({
                        "color": "red",
                        "font-size": "14px"
                    });
                } else {
                    $("#edit_dailyrate").removeClass("is-valid").addClass("is-invalid");
                    $(".drate-error").html('Please input Number only');
                    $(".drate-error").css({
                        "color": "red",
                        "font-size": "14px",
                        "display": "block"
                    });
                }
            };

            function isValidMrate2() {
                pattern = /^[0-9.,\s]+$/;
                var mothly_rate = $("#edit_mothlyrate").val();
                if (pattern.test(mothly_rate) && mothly_rate !== "") {
                    $("#edit_mothlyrate").removeClass("is-invalid").addClass("is-valid");
                    $(".mrate-error").css({
                        "color": "green",
                        "font-size": "14px",
                        "display": "none"
                    });
                    return true;
                } else if (mothly_rate === "") {
                    $("#edit_mothlyrate").removeClass("is-valid").addClass("is-invalid");
                    $(".mrate-error").html('Required Monthly Rate');
                    $(".mrate-error").css({
                        "color": "red",
                        "font-size": "14px"
                    });
                } else {
                    $("#edit_mothlyrate").removeClass("is-valid").addClass("is-invalid");
                    $(".mrate-error").html('Please input Number only');
                    $(".mrate-error").css({
                        "color": "red",
                        "font-size": "14px",
                        "display": "block"
                    });
                }
            };


            function isValidSSSNo2() {
                pattern = /^[0-9-\s]+$/;
                var sss_no = $("#edit_sssno").val();
                if (pattern.test(sss_no) && sss_no !== "") {
                    $("#edit_sssno").removeClass("is-invalid").addClass("is-valid");
                    $(".sssno-error").css({
                        "color": "green",
                        "font-size": "14px",
                        "display": "none"
                    });
                    return true;
                } else if (sss_no === "") {
                    $("#edit_sssno").removeClass("is-valid").addClass("is-invalid");
                    $(".sssno-error").html('Required SSS Number');
                    $(".sssno-error").css({
                        "color": "red",
                        "font-size": "14px"
                    });
                } else {
                    $("#edit_sssno").removeClass("is-valid").addClass("is-invalid");
                    $(".sssno-error").html('Please input Number only');
                    $(".sssno-error").css({
                        "color": "red",
                        "font-size": "14px",
                        "display": "block"
                    });
                }
            };

            function isValidPhilHealth2() {
                pattern = /^[0-9-\s]+$/;
                var philHealth = $("#edit_philHealth").val();
                if (pattern.test(philHealth) && philHealth !== "") {
                    $("#edit_philHealth").removeClass("is-invalid").addClass("is-valid");
                    $(".phil-error").css({
                        "color": "green",
                        "font-size": "14px",
                        "display": "none"
                    });
                    return true;
                } else if (philHealth === "") {
                    $("#edit_philHealth").removeClass("is-valid").addClass("is-invalid");
                    $(".phil-error").html('Required PhilHealth Number');
                    $(".phil-error").css({
                        "color": "red",
                        "font-size": "14px"
                    });
                } else {
                    $("#edit_philHealth").removeClass("is-valid").addClass("is-invalid");
                    $(".phil-error").html('Please input Number only');
                    $(".phil-error").css({
                        "color": "red",
                        "font-size": "14px",
                        "display": "block"
                    });
                }
            };

           function isValidPagibig2() {
                pattern = /^[0-9-\s]+$/;
                var pag_ibig = $("#edit_pagibig").val();
                if (pattern.test(pag_ibig) && pag_ibig !== "") {
                    $("#edit_pagibig").removeClass("is-invalid").addClass("is-valid");
                    $(".ibig-error").css({
                        "color": "green",
                        "font-size": "14px",
                        "display": "none"
                    });
                    return true;
                } else if (pag_ibig === "") {
                    $("#edit_pagibig").removeClass("is-valid").addClass("is-invalid");
                    $(".ibig-error").html('Required Pag-ibig Number');
                    $(".ibig-error").css({
                        "color": "red",
                        "font-size": "14px"
                    });
                } else {
                    $("#edit_pagibig").removeClass("is-valid").addClass("is-invalid");
                    $(".ibig-error").html('Please input Number only');
                    $(".ibig-error").css({
                        "color": "red",
                        "font-size": "14px",
                        "display": "block"
                    });
                }
            };

           function isValidDesignation2() {
                var pattern = /^[a-zA-Z \s]+$/;
                var designation = $("#edit_designation").val();
                if (pattern.test(designation) && designation !== "") {
                    $("#edit_designation").removeClass("is-invalid").addClass("is-valid");
                    $(".desig-error").css({
                        "color": "green",
                        "font-size": "14px",
                        "display": "none"
                    });
                    return true;
                } else if (designation === "") {
                    $("#edit_designation").removeClass("is-valid").addClass("is-invalid");
                    $(".desig-error").html('Required Designation');
                    $(".desig-error").css({
                        "color": "red",
                        "font-size": "14px"
                    });
                } else {
                    $("#edit_designation").removeClass("is-valid").addClass("is-invalid");
                    $(".desig-error").html('Please input Character only');
                    $(".desig-error").css({
                        "color": "red",
                        "font-size": "14px",
                        "display": "block"
                    });
                }
            };


            function isValidDepartment2() {
                if ($("#edit_departmentid").val() === "") {
                    $("#edit_departmentid").addClass("is-invalid");
                    $(".dept-error").html('Required Department');
                    $(".dept-error").css({
                        "color": "red",
                        "font-size": "14px",
                    });
                    return false;
                } else {
                    $("#edit_departmentid").removeClass("is-invalid").addClass("is-valid");
                     $(".dept-error").css({
                        "display": "none"
                    });
                    return true;
                }
            };


            function isValidDateHire2() {
                if ($("#edit_datehire").val() === "") {
                    $("#edit_datehire").addClass("is-invalid");
                    $(".dhire-error").html('Required Date hire');
                    $(".dhire-error").css({
                        "color": "red",
                        "font-size": "14px",
                    });
                    return false;
                } else {
                    $("#edit_datehire").removeClass("is-invalid").addClass("is-valid");
                     $(".dhire-error").css({
                        "display": "none"
                    });
                    return true;
                }
            };

             function isValidUname2() {
                var pattern = /^[a-zA-Z0-9 !_@#$%^&-*].*$/;
                var username = $("#edit_username").val();
                if (pattern.test(username) && username !== "") {
                    $("#edit_username").removeClass("is-invalid").addClass("is-valid");
                    $(".uname-error").css({
                        "color": "green",
                        "font-size": "14px",
                        "display": "none"
                    });
                    return true;
                } else if (username === "") {
                    $("#edit_username").removeClass("is-valid").addClass("is-invalid");
                    $(".uname-error").html('Required Username');
                    $(".uname-error").css({
                        "color": "red",
                        "font-size": "14px"
                    });
                } else {
                    $("#edit_username").removeClass("is-valid").addClass("is-invalid");
                    $(".uname-error").html('Please input Character');
                    $(".uname-error").css({
                        "color": "red",
                        "font-size": "14px",
                        "display": "block"
                    });
                }
            };

            function isValidPass2() {
                var pattern = /^[a-zA-Z0-9 !_@#$%^&-*].*$/;
                var password = $("#edit_password").val();
                if (pattern.test(password) && password !== "") {
                    $("#edit_password").removeClass("is-invalid").addClass("is-valid");
                    $(".pass-error").css({
                        "color": "green",
                        "font-size": "14px",
                        "display": "none"
                    });
                    return true;
                } else if (password === "") {
                    $("#edit_password").removeClass("is-valid").addClass("is-invalid");
                    $(".pass-error").html('Required Password');
                    $(".pass-error").css({
                        "color": "red",
                        "font-size": "14px"
                    });
                } else {
                    $("#edit_password").removeClass("is-valid").addClass("is-invalid");
                    $(".pass-error").html('Please input Secure Password');
                    $(".pass-error").css({
                        "color": "red",
                        "font-size": "14px",
                        "display": "block"
                    });
                }
            };

            function isValidEmpStat2() {
                if ($("#edit_empstatus").val() === "") {
                    $("#edit_empstatus").addClass("is-invalid");
                    $(".dhire-error").html('Required Status');
                    $(".dhire-error").css({
                        "color": "red",
                        "font-size": "14px",
                    });
                    return false;
                } else {
                    $("#edit_empstatus").removeClass("is-invalid").addClass("is-valid");
                     $(".dhire-error").css({
                        "display": "none"
                    });
                    return true;
                }
            };

        
            isValidEmpIDNo2();
            isValidFName2();
            isValidMname2();
            isValidLname2();
            isValidDbirth2();
            isValiCnumber2();
            isValiCAddress2();
            isValidGender2();
            isValidEmail2();
            isValidDrate2();
            isValidMrate2();
            isValidSSSNo2();
            isValidPhilHealth2();
            isValidPagibig2();
            isValidDesignation2();
            isValidDepartment2();
            isValidDateHire2();
            isValidUname2();
            isValidPass2();
            isValidEmpStat2();


            if (

                isValidEmpIDNo2() === true && isValidFName2() === true && isValidMname2() === true
                && isValidLname2() === true && isValidDbirth2() === true
                && isValiCnumber2() === true && isValiCAddress2() === true
                && isValidGender2() === true && isValidEmail2() === true
                && isValidDrate2() === true && isValidMrate2() === true
                && isValidSSSNo2() === true && isValidPhilHealth2() === true
                && isValidPagibig2() === true && isValidDesignation2() === true
                && isValidDepartment2() === true && isValidDateHire2() === true
                && isValidUname2() === true && isValidPass2() === true && isValidEmpStat2() === true

              ) {

                $.ajax({
                    url: '../config/init/edit_employee.php',
                    type: "POST",
                    data: data,
                    processData: false,
                    contentType: false,
                    async: false,
                    cache: false,
                    success: function(response) {
                         $.toast({
                                heading: 'Success',
                                text: 'Update Employee Successfully.',
                                showHideTransition: 'slide',
                                icon: 'success',
                                position: 'bottom-right',
                                hideAfter: 2000  
                            })
                         setTimeout(function () {  
                           location.reload(true);
                         }, 2500);
                          
                    },
                    error: function(response) {
                        console.log("Failed");
                    }
                });
            }

        });
    });
</script>