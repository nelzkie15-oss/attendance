<div class="modal" id="delschedule-modal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="bi bi-plus-circle"></i> Delete Schedule</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST">
            <div class="modal-body">
                <div class="col-lg-12 mb-1">
                    <div class="form-group">
                        <label for="inputTime"><b>Employee Name:</b></label>
                        <input type="text" id="delete_empid" class="form-control" autocomplete="off" readonly="">
                        <span class="deptname-error"></span>
                    </div>
                </div>

            </div>
            <div class="modal-footer">
                <input type="hidden" name="" id="delete_empid">
                <button type="button" class="btn btn-outline-danger" data-bs-dismiss="modal">No</button>
                <button type="button" class="btn btn-outline-primary" id="btn-delsched">Yes</button>
            </div>
           </form>
        </div>
    </div>
</div>

<script type="text/javascript">
    document.addEventListener('DOMContentLoaded', () => {
        let btn = document.querySelector('#btn-delsched');
        btn.addEventListener('click', (e) => {
            e.preventDefault();

            const schedule_id = document.querySelector('input[id=delete_empid]').value;
            console.log(schedule_id);

            var data = new FormData(this.form);

            data.append('schedule_id', schedule_id);



                $.ajax({
                    url: '../config/init/delete_schedule.php',
                    type: "POST",
                    data: data,
                    processData: false,
                    contentType: false,
                    async: false,
                    cache: false,
                    success: function(response) {
                         $.toast({
                                heading: 'Success',
                                text: 'Delete Schedule Successfully.',
                                showHideTransition: 'slide',
                                icon: 'success',
                                position: 'bottom-right',
                                hideAfter: 2000  
                            })
                         setTimeout(function () {  
                           location.reload(true);
                         }, 2500);
                          
                    },
                    error: function(response) {
                        console.log("Failed");
                    }
                });
           // }

        });
    });
</script>