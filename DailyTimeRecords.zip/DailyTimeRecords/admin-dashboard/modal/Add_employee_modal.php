<div class="modal" id="employee-modal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content ">
            <div class="modal-header">
                <h5 class="modal-title"><i class="bi bi-plus-circle"></i> New Employee</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="form-group">
                    <center>
                        <div class="file-uploader">
                            <label name="upload-label" class="upload-img-btn" style="border-style: dashed;">
                                <input type="file" id="photo" name="photo" class="upload-field-1" style="display:none;" accept="image/*" title="Upload Foto.." />
                                <img class="preview-1" src="../assets/images/image-asset.png" style="width:150px!important;" title="Upload Photo.." />
                            </label>
                        </div>
                    <span class="pic-error"></span>

                    </center>
                </div>
                <div class="row">
                    <div class="col-lg-3 mt-2">
                        <div class="form-group">
                            <label for="inputTime"><b>Employee ID No.:</b></label>
                            <input type="text" id="empid_no" class="form-control" autocomplete="off">
                            <span class="empno-error"></span>
                        </div>
                    </div>
                    <div class="col-lg-3 mt-2">
                        <div class="form-group">
                            <label for="inputTime"><b>First Name:</b></label>
                            <input type="text" id="first_name" class="form-control" autocomplete="off">
                            <span class="fname-error"></span>
                        </div>
                    </div>
                    <div class="col-lg-3 mt-2">
                        <div class="form-group">
                            <label for="inputTime"><b>Middle Name:</b></label>
                            <input type="text" id="middle_name" class="form-control" placeholder="(Optionnal)" autocomplete="off">
                            <span class=""></span>
                        </div>
                    </div>
                    <div class="col-lg-3 mt-2">
                        <div class="form-group">
                            <label for="inputTime"><b>Last Name: </b></label>
                            <input type="text" id="last_name" class="form-control" autocomplete="off">
                            <span class="lname-error"></span>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-lg-3 mt-2">
                        <div class="form-group">
                            <label for="inputTime"><b>Date of Birth:</b></label>
                            <input type="date"  id="date_ofbirth" class="form-control" autocomplete="off">
                            <span class="dbirth-error"></span>
                        </div>
                    </div>
                    <div class="col-lg-3 mt-2">
                        <div class="form-group">
                            <label for="inputTime"><b>Contact Number:</b></label>
                            <input type="text" id="contact_number" class="form-control" minlength="11" maxlength="11" autocomplete="off">
                            <span class="cnumber-error"></span>
                        </div>
                    </div>
                    <div class="col-lg-6 mt-2">
                        <div class="form-group">
                            <label for="inputTime"><b>Complete Address: </b></label>
                            <input type="text" id="complete_address" class="form-control" autocomplete="off">
                            <span class="caddress-error"></span>
                        </div>
                    </div>
                </div>


                <div class="row">
                    <div class="col-lg-3 mt-2">
                        <div class="form-group">
                            <label for="inputTime"><b>Gender: </b></label>
                            <select class="form-control" id="gender"  autocomplete="off">
                                <option value="">&larr; Select Gender &rarr;</option>
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                            </select>
                            <span class="gen-error"></span>
                        </div>
                    </div>
                    <div class="col-lg-3 mt-2">
                        <div class="form-group">
                            <label for="inputTime"><b>Email: </b></label>
                            <input type="email" id="email" class="form-control" placeholder="(Optionnal)" autocomplete="off">
                            <span class=""></span>
                        </div>
                    </div>
                    <div class="col-lg-3 mt-2">
                        <div class="form-group">
                            <label for="inputTime"><b>Daily Rate:</b></label>
                            <input type="text" id="daily_rate" class="form-control" autocomplete="off">
                            <span class="drate-error"></span>
                        </div>
                    </div>
                    <div class="col-lg-3 mt-2">
                        <div class="form-group">
                            <label for="inputTime"><b>Monthly Rate:</b></label>
                            <input type="text" id="mothly_rate" class="form-control" autocomplete="off">
                            <span class="mrate-error"></span>
                        </div>
                    </div>

                </div>

                <div class="row">
                    <div class="col-lg-4 mt-2">
                        <div class="form-group">
                            <label for="inputTime"><b>SSS #: </b></label>
                            <input type="text" id="sss_no" class="form-control" autocomplete="off">
                            <span class="sssno-error"></span>
                        </div>
                    </div>
                    <div class="col-lg-4 mt-2">
                        <div class="form-group">
                            <label for="inputTime"><b>PhilHealth #:</b></label>
                            <input type="text" id="philHealth" class="form-control" autocomplete="off">
                            <span class="phil-error"></span>
                        </div>
                    </div>
                    <div class="col-lg-4 mt-2">
                        <div class="form-group">
                            <label for="inputTime"><b>Pag-ibig #:</b></label>
                            <input type="text" id="pag_ibig" class="form-control" autocomplete="off">
                            <span class="ibig-error"></span>
                        </div>
                    </div>

                </div>
                <div class="row">
                    <div class="col-lg-4 mt-2">
                        <div class="form-group">
                            <label for="inputTime"><b>Designation: </b></label>
                            <input type="text" id="designation" class="form-control" autocomplete="off">
                            <span class="desig-error"></span>
                        </div>
                    </div>
                    <div class="col-lg-4 mt-2">
                        <div class="form-group">
                            <label for="inputTime"><b>Department: </b></label>
                            <select class="form-control" id="department_id"  autocomplete="off">
                                <option value="">&larr; Select Department &rarr;</option>
                                <?php
                                 require_once "../config/DTR_class.php";
                                  $conn = new Attendance();
                                  $depts = $conn->FetchDepartment();
                                 foreach ($depts as $row) { ?>
                                  <option value="<?php echo htmlentities($row['department_id']); ?>"><?php echo htmlentities($row['department_name']); ?></option>
                                <?php } ?>
                            </select>
                            <span class="dept-error"></span>
                        </div>
                    </div>
                    <div class="col-lg-4 mt-2">
                        <div class="form-group">
                            <label for="inputTime"><b>Date Hire:</b></label>
                            <input type="date" id="date_hire" class="form-control" autocomplete="off">
                            <span class="dhire-error"></span>
                        </div>
                    </div>

                </div>

                <div class="row">
                    <div class="col-lg-4 mt-2">
                        <div class="form-group">
                            <label for="inputTime"><b>Username: </b></label>
                            <input type="text" id="username" class="form-control" autocomplete="off">
                            <span class="uname-error"></span>
                        </div>
                    </div>
                    <div class="col-lg-4 mt-2">
                        <div class="form-group">
                            <label for="inputTime"><b>Password:</b></label>
                            <input type="password" id="password" class="form-control" autocomplete="off">
                            <span class="pass-error"></span>
                        </div>
                    </div>

                    <div class="col-lg-4 mt-2">
                        <div class="form-group">
                            <label for="inputTime"><b>Status: </b></label>
                            <select class="form-control" id="emp_status" autocomplete="off" >
                                <option value="">&larr; Select Status &rarr;</option>
                                <option value="Probationary">Probationary</option>
                                <option value="Regular">Regular</option>
                             </select>
                          <span class="dhire-error"></span>
                        </div>
                    </div>
                </div>


            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-danger" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-outline-primary" id="btn-employee">Save</button>
            </div>
        </div>
    </div>
</div>


<script type="text/javascript">
    document.addEventListener('DOMContentLoaded', () => {
        let btn = document.querySelector('#btn-employee');
        btn.addEventListener('click', (e) => {
            e.preventDefault();

            const images = document.querySelector('input[id=photo]').value;
            console.log(images);

            const empid_no = document.querySelector('input[id=empid_no]').value;
            console.log(empid_no);

            const first_name = document.querySelector('input[id=first_name]').value;
            console.log(first_name);

            const middle_name = document.querySelector('input[id=middle_name]').value;
            console.log(middle_name);

            const last_name = document.querySelector('input[id=last_name]').value;
            console.log(last_name);

            const date_ofbirth = document.querySelector('input[id=date_ofbirth]').value;
            console.log(date_ofbirth);

            const contact_number = document.querySelector('input[id=contact_number]').value;
            console.log(contact_number);

            const complete_address = document.querySelector('input[id=complete_address]').value;
            console.log(complete_address);

            const gender = $('#gender option:selected').val();
            console.log(gender);

            const email = document.querySelector('input[id=email]').value;
            console.log(email);

            const daily_rate = document.querySelector('input[id=daily_rate]').value;
            console.log(daily_rate);

            const mothly_rate = document.querySelector('input[id=mothly_rate]').value;
            console.log(mothly_rate);

            const sss_no = document.querySelector('input[id=sss_no]').value;
            console.log(sss_no);

            const philHealth = document.querySelector('input[id=philHealth]').value;
            console.log(philHealth);

            const pag_ibig = document.querySelector('input[id=pag_ibig]').value;
            console.log(pag_ibig);

            const designation = document.querySelector('input[id=designation]').value;
            console.log(designation);

            const department_id = $('#department_id option:selected').val();
            console.log(department_id);

            const date_hire = document.querySelector('input[id=date_hire]').value;
            console.log(date_hire);

           const username = document.querySelector('input[id=username]').value;
            console.log(username);

            const password = document.querySelector('input[id=password]').value;
            console.log(password);

            const emp_status = $('#emp_status option:selected').val();
            console.log(emp_status);



            var data = new FormData(this.form);

            data.append('images', $('#photo')[0].files[0]);
            data.append('empid_no', empid_no);
            data.append('first_name', first_name);
            data.append('middle_name', middle_name);
            data.append('last_name', last_name);
            data.append('date_ofbirth', date_ofbirth);
            data.append('contact_number', contact_number);
            data.append('complete_address', complete_address);
            data.append('gender', gender);
            data.append('email', email);
            data.append('daily_rate', daily_rate);
            data.append('mothly_rate', mothly_rate);
            data.append('sss_no', sss_no);
            data.append('philHealth', philHealth);
            data.append('pag_ibig', pag_ibig);
            data.append('designation', designation);
            data.append('department_id', department_id);
            data.append('date_hire', date_hire);
            data.append('username', username);
            data.append('password', password);
            data.append('emp_status', emp_status);

             function isValidPhoto() {
                if ($("#photo").val() === "") {
                    $("#photo").addClass("is-invalid");
                    $(".pic-error").html('Required Photo');
                    $(".pic-error").css({
                        "color": "red",
                        "font-size": "14px",
                    });
                    return false;
                } else {
                    $("#photo").removeClass("is-invalid").addClass("is-valid");
                     $(".pic-error").css({
                        "display": "none"
                    });
                    return true;
                }
            };



            function isValidEmpIDNo() {
                var pattern = /^[a-zA-Z 0-9\s]+$/;
                var empid_no = $("#empid_no").val();
                if (pattern.test(empid_no) && empid_no !== "") {
                    $("#empid_no").removeClass("is-invalid").addClass("is-valid");
                    $(".empno-error").css({
                        "color": "green",
                        "font-size": "14px",
                        "display": "none"
                    });
                    return true;
                } else if (empid_no === "") {
                    $("#empid_no").removeClass("is-valid").addClass("is-invalid");
                    $(".empno-error").html('Required Employee ID No.');
                    $(".empno-error").css({
                        "color": "red",
                        "font-size": "14px"
                    });
                } else {
                    $("#empid_no").removeClass("is-valid").addClass("is-invalid");
                    $(".empno-error").html('Please input Character/Number');
                    $(".empno-error").css({
                        "color": "red",
                        "font-size": "14px",
                        "display": "block"
                    });
                }
            };


            function isValidFName() {
                var pattern = /^[a-zA-Z \s]+$/;
                var first_name = $("#first_name").val();
                if (pattern.test(first_name) && first_name !== "") {
                    $("#first_name").removeClass("is-invalid").addClass("is-valid");
                    $(".fname-error").css({
                        "color": "green",
                        "font-size": "14px",
                        "display": "none"
                    });
                    return true;
                } else if (first_name === "") {
                    $("#first_name").removeClass("is-valid").addClass("is-invalid");
                    $(".fname-error").html('Required First Name');
                    $(".fname-error").css({
                        "color": "red",
                        "font-size": "14px"
                    });
                } else {
                    $("#first_name").removeClass("is-valid").addClass("is-invalid");
                    $(".fname-error").html('Please input Character only');
                    $(".fname-error").css({
                        "color": "red",
                        "font-size": "14px",
                        "display": "block"
                    });
                }
            };



           function isValidMname() {
                if ($("#middle_name").val() === "" && $("#middle_name").val()) {
                    $("#middle_name").removeClass("is-invalid").addClass("is-valid");
                    return false;
                } else {
                    $("#middle_name").removeClass("is-invalid").addClass("is-valid");
                    return true;
                }
            };


            function isValidLname() {
                var pattern = /^[a-zA-Z \s]+$/;
                var last_name = $("#last_name").val();
                if (pattern.test(last_name) && last_name !== "") {
                    $("#last_name").removeClass("is-invalid").addClass("is-valid");
                    $(".lname-error").css({
                        "color": "green",
                        "font-size": "14px",
                        "display": "none"
                    });
                    return true;
                } else if (last_name === "") {
                    $("#last_name").removeClass("is-valid").addClass("is-invalid");
                    $(".lname-error").html('Required Last Name');
                    $(".lname-error").css({
                        "color": "red",
                        "font-size": "14px"
                    });
                } else {
                    $("#last_name").removeClass("is-valid").addClass("is-invalid");
                    $(".lname-error").html('Please input Character only');
                    $(".lname-error").css({
                        "color": "red",
                        "font-size": "14px",
                        "display": "block"
                    });
                }
            };

            function isValidDbirth() {
                if ($("#date_ofbirth").val() === "") {
                    $("#date_ofbirth").addClass("is-invalid");
                    $(".dbirth-error").html('Required Date of Birth');
                    $(".dbirth-error").css({
                        "color": "red",
                        "font-size": "14px",
                    });
                    return false;
                } else {
                    $("#date_ofbirth").removeClass("is-invalid").addClass("is-valid");
                     $(".dbirth-error").css({
                        "display": "none"
                    });
                    return true;
                }
            };


            function isValiCnumber() {
                var pattern = /^[0-9]{11}$/;
                var contact_number = $("#contact_number").val();
                if (pattern.test(contact_number) && contact_number !== "") {
                    $("#contact_number").removeClass("is-invalid").addClass("is-valid");
                    $(".cnumber-error").css({
                        "color": "green",
                        "font-size": "14px",
                        "display": "none"
                    });
                    return true;
                } else if (contact_number === "") {
                    $("#contact_number").removeClass("is-valid").addClass("is-invalid");
                    $(".cnumber-error").html('Required Contact Number');
                    $(".cnumber-error").css({
                        "color": "red",
                        "font-size": "14px"
                    });
                } else {
                    $("#contact_number").removeClass("is-valid").addClass("is-invalid");
                    $(".cnumber-error").html('Please input Number only');
                    $(".cnumber-error").css({
                        "color": "red",
                        "font-size": "14px",
                        "display": "block"
                    });
                }
            };

           function isValiCAddress() {
                var pattern = /^[a-zA-Z0-9 !_@#$%^&-*].*$/;
                var complete_address = $("#complete_address").val();
                if (pattern.test(complete_address) && complete_address !== "") {
                    $("#complete_address").removeClass("is-invalid").addClass("is-valid");
                    $(".caddress-error").css({
                        "color": "green",
                        "font-size": "14px",
                        "display": "none"
                    });
                    return true;
                } else if (complete_address === "") {
                    $("#complete_address").removeClass("is-valid").addClass("is-invalid");
                    $(".caddress-error").html('Required Complete Address');
                    $(".caddress-error").css({
                        "color": "red",
                        "font-size": "14px"
                    });
                } else {
                    $("#complete_address").removeClass("is-valid").addClass("is-invalid");
                    $(".caddress-error").html('Please input Character/Number');
                    $(".caddress-error").css({
                        "color": "red",
                        "font-size": "14px",
                        "display": "block"
                    });
                }
            };


            function isValidGender() {
                if ($("#gender").val() === "") {
                    $("#gender").addClass("is-invalid");
                    $(".gen-error").html('Required Gender');
                    $(".gen-error").css({
                        "color": "red",
                        "font-size": "14px",
                    });
                    return false;
                } else {
                    $("#gender").removeClass("is-invalid").addClass("is-valid");
                     $(".gen-error").css({
                        "display": "none"
                    });
                    return true;
                }
            };


            function isValidEmail() {
                if ($("#email").val() === "" && $("#email").val()) {
                    $("#email").removeClass("is-invalid").addClass("is-valid");
                    return false;
                } else {
                    $("#email").removeClass("is-invalid").addClass("is-valid");
                    return true;
                }
            };

           function isValidDrate() {
                pattern = /^[0-9.,\s]+$/;
                var daily_rate = $("#daily_rate").val();
                if (pattern.test(daily_rate) && daily_rate !== "") {
                    $("#daily_rate").removeClass("is-invalid").addClass("is-valid");
                    $(".drate-error").css({
                        "color": "green",
                        "font-size": "14px",
                        "display": "none"
                    });
                    return true;
                } else if (daily_rate === "") {
                    $("#daily_rate").removeClass("is-valid").addClass("is-invalid");
                    $(".drate-error").html('Required Daily Rate');
                    $(".drate-error").css({
                        "color": "red",
                        "font-size": "14px"
                    });
                } else {
                    $("#daily_rate").removeClass("is-valid").addClass("is-invalid");
                    $(".drate-error").html('Please input Number only');
                    $(".drate-error").css({
                        "color": "red",
                        "font-size": "14px",
                        "display": "block"
                    });
                }
            };

            function isValidMrate() {
                pattern = /^[0-9.,\s]+$/;
                var mothly_rate = $("#mothly_rate").val();
                if (pattern.test(mothly_rate) && mothly_rate !== "") {
                    $("#mothly_rate").removeClass("is-invalid").addClass("is-valid");
                    $(".mrate-error").css({
                        "color": "green",
                        "font-size": "14px",
                        "display": "none"
                    });
                    return true;
                } else if (mothly_rate === "") {
                    $("#mothly_rate").removeClass("is-valid").addClass("is-invalid");
                    $(".mrate-error").html('Required Monthly Rate');
                    $(".mrate-error").css({
                        "color": "red",
                        "font-size": "14px"
                    });
                } else {
                    $("#mothly_rate").removeClass("is-valid").addClass("is-invalid");
                    $(".mrate-error").html('Please input Number only');
                    $(".mrate-error").css({
                        "color": "red",
                        "font-size": "14px",
                        "display": "block"
                    });
                }
            };


            function isValidSSSNo() {
                pattern = /^[0-9-\s]+$/;
                var sss_no = $("#sss_no").val();
                if (pattern.test(sss_no) && sss_no !== "") {
                    $("#sss_no").removeClass("is-invalid").addClass("is-valid");
                    $(".sssno-error").css({
                        "color": "green",
                        "font-size": "14px",
                        "display": "none"
                    });
                    return true;
                } else if (sss_no === "") {
                    $("#sss_no").removeClass("is-valid").addClass("is-invalid");
                    $(".sssno-error").html('Required SSS Number');
                    $(".sssno-error").css({
                        "color": "red",
                        "font-size": "14px"
                    });
                } else {
                    $("#sss_no").removeClass("is-valid").addClass("is-invalid");
                    $(".sssno-error").html('Please input Number only');
                    $(".sssno-error").css({
                        "color": "red",
                        "font-size": "14px",
                        "display": "block"
                    });
                }
            };

            function isValidPhilHealth() {
                pattern = /^[0-9-\s]+$/;
                var philHealth = $("#philHealth").val();
                if (pattern.test(philHealth) && philHealth !== "") {
                    $("#philHealth").removeClass("is-invalid").addClass("is-valid");
                    $(".phil-error").css({
                        "color": "green",
                        "font-size": "14px",
                        "display": "none"
                    });
                    return true;
                } else if (philHealth === "") {
                    $("#philHealth").removeClass("is-valid").addClass("is-invalid");
                    $(".phil-error").html('Required PhilHealth Number');
                    $(".phil-error").css({
                        "color": "red",
                        "font-size": "14px"
                    });
                } else {
                    $("#philHealth").removeClass("is-valid").addClass("is-invalid");
                    $(".phil-error").html('Please input Number only');
                    $(".phil-error").css({
                        "color": "red",
                        "font-size": "14px",
                        "display": "block"
                    });
                }
            };

           function isValidPagibig() {
                pattern = /^[0-9-\s]+$/;
                var pag_ibig = $("#pag_ibig").val();
                if (pattern.test(pag_ibig) && pag_ibig !== "") {
                    $("#pag_ibig").removeClass("is-invalid").addClass("is-valid");
                    $(".ibig-error").css({
                        "color": "green",
                        "font-size": "14px",
                        "display": "none"
                    });
                    return true;
                } else if (pag_ibig === "") {
                    $("#pag_ibig").removeClass("is-valid").addClass("is-invalid");
                    $(".ibig-error").html('Required Pag-ibig Number');
                    $(".ibig-error").css({
                        "color": "red",
                        "font-size": "14px"
                    });
                } else {
                    $("#pag_ibig").removeClass("is-valid").addClass("is-invalid");
                    $(".ibig-error").html('Please input Number only');
                    $(".ibig-error").css({
                        "color": "red",
                        "font-size": "14px",
                        "display": "block"
                    });
                }
            };

           function isValidDesignation() {
                var pattern = /^[a-zA-Z \s]+$/;
                var designation = $("#designation").val();
                if (pattern.test(designation) && designation !== "") {
                    $("#designation").removeClass("is-invalid").addClass("is-valid");
                    $(".desig-error").css({
                        "color": "green",
                        "font-size": "14px",
                        "display": "none"
                    });
                    return true;
                } else if (designation === "") {
                    $("#designation").removeClass("is-valid").addClass("is-invalid");
                    $(".desig-error").html('Required Designation');
                    $(".desig-error").css({
                        "color": "red",
                        "font-size": "14px"
                    });
                } else {
                    $("#designation").removeClass("is-valid").addClass("is-invalid");
                    $(".desig-error").html('Please input Character only');
                    $(".desig-error").css({
                        "color": "red",
                        "font-size": "14px",
                        "display": "block"
                    });
                }
            };


            function isValidDepartment() {
                if ($("#department_id").val() === "") {
                    $("#department_id").addClass("is-invalid");
                    $(".dept-error").html('Required Department');
                    $(".dept-error").css({
                        "color": "red",
                        "font-size": "14px",
                    });
                    return false;
                } else {
                    $("#department_id").removeClass("is-invalid").addClass("is-valid");
                     $(".dept-error").css({
                        "display": "none"
                    });
                    return true;
                }
            };


            function isValidDateHire() {
                if ($("#date_hire").val() === "") {
                    $("#date_hire").addClass("is-invalid");
                    $(".dhire-error").html('Required Date hire');
                    $(".dhire-error").css({
                        "color": "red",
                        "font-size": "14px",
                    });
                    return false;
                } else {
                    $("#date_hire").removeClass("is-invalid").addClass("is-valid");
                     $(".dhire-error").css({
                        "display": "none"
                    });
                    return true;
                }
            };

             function isValidUname() {
                var pattern = /^[a-zA-Z0-9 !_@#$%^&-*].*$/;
                var username = $("#username").val();
                if (pattern.test(username) && username !== "") {
                    $("#username").removeClass("is-invalid").addClass("is-valid");
                    $(".uname-error").css({
                        "color": "green",
                        "font-size": "14px",
                        "display": "none"
                    });
                    return true;
                } else if (username === "") {
                    $("#username").removeClass("is-valid").addClass("is-invalid");
                    $(".uname-error").html('Required Username');
                    $(".uname-error").css({
                        "color": "red",
                        "font-size": "14px"
                    });
                } else {
                    $("#username").removeClass("is-valid").addClass("is-invalid");
                    $(".uname-error").html('Please input Character');
                    $(".uname-error").css({
                        "color": "red",
                        "font-size": "14px",
                        "display": "block"
                    });
                }
            };

            function isValidPass() {
                var pattern = /^[a-zA-Z0-9 !_@#$%^&-*].*$/;
                var password = $("#password").val();
                if (pattern.test(password) && password !== "") {
                    $("#password").removeClass("is-invalid").addClass("is-valid");
                    $(".pass-error").css({
                        "color": "green",
                        "font-size": "14px",
                        "display": "none"
                    });
                    return true;
                } else if (password === "") {
                    $("#password").removeClass("is-valid").addClass("is-invalid");
                    $(".pass-error").html('Required Password');
                    $(".pass-error").css({
                        "color": "red",
                        "font-size": "14px"
                    });
                } else {
                    $("#password").removeClass("is-valid").addClass("is-invalid");
                    $(".pass-error").html('Please input Secure Password');
                    $(".pass-error").css({
                        "color": "red",
                        "font-size": "14px",
                        "display": "block"
                    });
                }
            };

            function isValidEmpStat() {
                if ($("#emp_status").val() === "") {
                    $("#emp_status").addClass("is-invalid");
                    $(".dhire-error").html('Required Status');
                    $(".dhire-error").css({
                        "color": "red",
                        "font-size": "14px",
                    });
                    return false;
                } else {
                    $("#emp_status").removeClass("is-invalid").addClass("is-valid");
                     $(".dhire-error").css({
                        "display": "none"
                    });
                    return true;
                }
            };

            isValidPhoto();
            isValidEmpIDNo();
            isValidFName();
            isValidMname();
            isValidLname();
            isValidDbirth();
            isValiCnumber();
            isValiCAddress();
            isValidGender();
            isValidEmail();
            isValidDrate();
            isValidMrate();
            isValidSSSNo();
            isValidPhilHealth();
            isValidPagibig();
            isValidDesignation();
            isValidDepartment();
            isValidDateHire();
            isValidUname();
            isValidPass();
            isValidEmpStat();


            if (

                isValidPhoto() === true && isValidEmpIDNo() === true && isValidFName() === true && isValidMname() === true
                && isValidLname() === true && isValidDbirth() === true
                && isValiCnumber() === true && isValiCAddress() === true
                && isValidGender() === true && isValidEmail() === true
                && isValidDrate() === true && isValidMrate() === true
                && isValidSSSNo() === true && isValidPhilHealth() === true
                && isValidPagibig() === true && isValidDesignation() === true
                && isValidDepartment() === true && isValidDateHire() === true
                && isValidUname() === true && isValidPass() === true && isValidEmpStat() === true

              ) {

                $.ajax({
                    url: '../config/init/add_employee.php',
                    type: "POST",
                    data: data,
                    processData: false,
                    contentType: false,
                    async: false,
                    cache: false,
                    success: function(response) {
                         $.toast({
                                heading: 'Success',
                                text: 'Added Employee Successfully.',
                                showHideTransition: 'slide',
                                icon: 'success',
                                position: 'bottom-right',
                                hideAfter: 2000  
                            })
                         setTimeout(function () {  
                           location.reload(true);
                         }, 2500);
                          
                    },
                    error: function(response) {
                        console.log("Failed");
                    }
                });
            }

        });
    });
</script>