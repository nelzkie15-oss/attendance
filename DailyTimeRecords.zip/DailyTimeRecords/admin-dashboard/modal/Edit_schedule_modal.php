<div class="modal" id="editschedule-modal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="bi bi-plus-circle"></i> Edit Schedule</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST">
            <div class="modal-body">

                <div class="col-lg-12 mb-1">
                    <label class="mb-1"><b>Employee Name: </b></label>
                    <div class="form-group">

                        <select class="form-control" id="edit_empid" aria-label="Default select example">
                            <option value="" selected="true">&larr; Select Employee &rarr;</option>
                              <?php
                                 require_once "../config/DTR_class.php";
                                  $conn = new Attendance();
                                  $depts = $conn->FetchEmployeesAdmin();
                                 foreach ($depts as $row) { ?>
                                  <option value="<?php echo htmlentities($row['emp_id']); ?>"><?php echo htmlentities($row['employee_name']); ?></option>
                                <?php } ?>
                        </select>
                        <span class="emp-error"></span>
                    </div>
                </div>


                <div class="row">
                    <div class="col-lg-6">
                        <div class="form-group">
                           <label for="inputTime"><b>From:</b></label>
                            <input type="time" id="edit_schedfrom" class="form-control">
                        </div>
                     <span class="schedfrom-error"></span>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label for="inputTime"><b>To: </b></label>
                            <input type="time" id="edit_schedto" class="form-control">
                        </div>
                        <span class="schedto-error"></span>
                    </div>
                </div>

            </div>
            <div class="modal-footer">
              <input type="hidden" name="" id="edit_scheduleid">
                <button type="button" class="btn btn-outline-danger" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-outline-primary" id="btn-editschedule">Update</button>
            </div>
            </form>
        </div>
    </div>
</div>
<script type="text/javascript">
    document.addEventListener('DOMContentLoaded', () => {
        let btn = document.querySelector('#btn-editschedule');
        btn.addEventListener('click', (e) => {
            e.preventDefault();

            const emp_id = $('#edit_empid option:selected').val();
            console.log(emp_id)

            const sched_from = document.querySelector('input[id=edit_schedfrom]').value;
            console.log(sched_from);

            const sched_to = document.querySelector('input[id=edit_schedto]').value;
            console.log(sched_to);

            const schedule_id = document.querySelector('input[id=edit_scheduleid]').value;
            console.log(schedule_id);

            var data = new FormData(this.form);

            data.append('emp_id', emp_id);
            data.append('sched_from', sched_from);
            data.append('sched_to', sched_to);
            data.append('schedule_id', schedule_id);

            function isValidEmp2() {
                      if ($("#edit_empid").val() === "") {
                           $("#edit_empid").addClass("is-invalid");
                           $(".emp-error").html('Please select Employee Name');
                           $(".emp-error").css({"color":"red","font-size":"14px"});
                          return false;
                      } else {
                          $("#edit_empid").removeClass("is-invalid").addClass("is-valid");
                          $(".emp-error").css({"display":"none"});
                          return true;
                      }
                  };
 
              function isValidSchedFrom2() {
                      if ($("#edit_schedfrom").val() === "") {
                           $("#edit_schedfrom").addClass("is-invalid");
                           $(".schedfrom-error").html('Required Schedule From');
                           $(".schedfrom-error").css({"color":"red","font-size":"14px"});
                          return false;
                      } else {
                           $("#edit_schedfrom").removeClass("is-invalid").addClass("is-valid");
                           $(".schedfrom-error").css({"display":"none"});
                          return true;
                      }
                  };
                    
              function isValidSchedTo2() {
                      if ($("#edit_schedto").val() === "") {
                           $("#edit_schedto").addClass("is-invalid");
                           $(".schedto-error").html('Required Schedule To');
                           $(".schedto-error").css({"color":"red","font-size":"14px"});
                          return false;
                      } else {
                           $("#edit_schedto").removeClass("is-invalid").addClass("is-valid");
                           $(".schedto-error").css({"display":"none"});
                          return true;
                      }
                  };  


            isValidEmp2();
            isValidSchedFrom2();
            isValidSchedTo2();

            if (isValidEmp2() === true && isValidSchedFrom2() === true && isValidSchedTo2() === true) {

                $.ajax({
                    url: '../config/init/edit_schedule.php',
                    type: "POST",
                    data: data,
                    processData: false,
                    contentType: false,
                    async: false,
                    cache: false,
                    success: function(response) {
                         $.toast({
                                heading: 'Success',
                                text: 'Update Schedule Successfully.',
                                showHideTransition: 'slide',
                                icon: 'success',
                                position: 'bottom-right',
                                hideAfter: 2000  
                            })
                         setTimeout(function () {  
                           location.reload(true);
                         }, 2500);
                          
                    },
                    error: function(response) {
                        console.log("Failed");
                    }
                });
            }

        });
    });
</script>