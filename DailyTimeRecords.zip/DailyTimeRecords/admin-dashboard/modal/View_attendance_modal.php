<div class="modal" id="viewAttendance-modal<?php echo htmlentities($row['emp_id']); ?>" tabindex="-1">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h6 class="modal-title"><i class="bi bi-zoom-in"></i> View Attendance per Employee</h6>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST">
                <div class="modal-body">
                    <table class="table table-bordered" style="font-size: 13px">
                        <thead>
                            <tr>
                                <th   style="text-align:center"></th>
                                <th  style="text-align:center"></th>
                                <th colspan="2"  style="text-align:center">MORNING</th>
                                <th colspan="2"  style="text-align:center">AFTERNOON</th>
                                <th colspan="2"  style="text-align:center">OVERTIME</th>
                            </tr>
                             <tr style="font-size: 12px;border-top: 1px solid black;">
                               <th style="text-align:center;background-color: #e1f7f7">DATE</th> 
                               <th style="text-align:center;background-color: #e1f7f7">SCHEDULE</th>
                               <th style="text-align:center;background-color: #e1f7f7">TIME IN</th>
                               <th style="text-align:center;background-color: #e1f7f7">TIME OUT</th>
                               <th style="text-align:center;background-color: #e1f7f7">TIME IN</th>
                               <th style="text-align:center;background-color: #e1f7f7">TIME OUT</th>
                               <th style="text-align:center;background-color: #e1f7f7">TIME IN</td>
                               <th style="text-align:center;background-color: #e1f7f7">TIME OUT</th>


                               <th style="text-align:center">LATE</th>
                               <th style="text-align:center">AM</th>
                               <th style="text-align:center">PM</th>
                               <th style="text-align:center">OT</th>
                               <th style="text-align:center">AM</th>
                               <th style="text-align:center">PM</th>
                               <th style="text-align:center">LATE</th>
                               <th style="text-align:center">OT</th>
                               <th style="text-align:center">TOTAL</th>


                            </tr>
                        </thead>
                        <tbody>
                         <?php
                            $getEmpId =  htmlentities($row['emp_id']);
                             require_once "../config/DTR_class.php";
                              $conn = new Attendance();
                              $depts = $conn->FetchEmpAttendance($getEmpId);
                            foreach ($depts as $row1) { ?>
      
                          <tr align="center">
                              <td><?= htmlentities(date("M d, Y",strtotime($row['logdate']))); ?></td>
                                <th style="text-align:center"><?php echo date("g:i a", strtotime(htmlentities($row1['sched_from']))) .' - '. date("g:i a", strtotime(htmlentities($row1['sched_to']))) ?></th>
                                <td>
                                    <?php if (empty(htmlentities($row1['time_in']))) {
                                      echo "";
                                     }else{
                                        echo date("g:i a", strtotime(htmlentities($row1['time_in'])));
                                     }

                                 ?></td>
                                <td>00:00</td>
                               <td>
                                    <?php if (empty(htmlentities($row1['time_out']))) {
                                      echo "";
                                     }else{
                                        echo date("g:i a", strtotime(htmlentities($row1['time_out'])));
                                     }

                                    ?></td>
                              <td>00:00</td>
                              <td>ot</td>
                              <td>ot</td>

                              <td>00:00</td>
                              <td>00:00</td>
                              <td>00:00</td>
                              <td>00:00</td>
                              <td>00:00</td>  
                              <td>00:00</td>
                              <td>00:00</td>
                              <td>00:00</td>
                              <td>00:00</td>
                            </tr>
                            <?php } ?>
                             <tr>
                              <?php 
                                $counts = $conn->Count_attendanceEmp($getEmpId);
                                $total = 0;
                                 foreach ($counts as $rows):
                                    $total += htmlentities($rows['attendance_id']); ///for order table compute
                              ?>
                               <?php endforeach ?> 
                                <td colspan="15"></td>
                                <td style="border-bottom: 1px solid black;border-left: none;width: 13%">No. of Days: <strong><?php echo $total;  ?></strong></td>
                            </tr>
                             <tr>
                                <td colspan="15"></td>
                                <td style="border-bottom: 1px solid black;border-left: none;width: 13%">Total OT(Hrs): <strong><?php echo $total;  ?></strong></td>
                                <td style="border-bottom: 1px solid black;border-left: none;width: 8%">Total: <strong><?php echo $total;  ?></strong></td>

                            </tr>
           
                        </tbody>
                    </table>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-danger" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-outline-primary" id="btn-department">Save</button>
                </div>
            </form>
        </div>
    </div>
</div>