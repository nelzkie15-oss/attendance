<div class="modal" id="schedule-modal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="bi bi-plus-circle"></i> New Schedule</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST">
            <div class="modal-body">

                <div class="col-lg-12 mb-1">
                    <label class="mb-1"><b>Employee Name: </b></label>
                    <div class="form-group">

                        <select class="form-control" id="emp_id" aria-label="Default select example">
                            <option value="" selected="true">&larr; Select Employee &rarr;</option>
                                <?php
                                 require_once "../config/DTR_class.php";
                                  $conn = new Attendance();
                                  $depts = $conn->FetchEmployeesAdmin();
                                 foreach ($depts as $row) { ?>
                                  <option value="<?php echo htmlentities($row['emp_id']); ?>"><?php echo htmlentities($row['employee_name']); ?></option>
                                <?php } ?>
                        </select>
                        <span class="emp-error"></span>
                    </div>
                </div>


                <div class="row">
                    <div class="col-lg-6">
                        <div class="form-group">
                           <label for="inputTime"><b>From:</b></label>
                            <input type="time" id="sched_from" class="form-control">
                        </div>
                     <span class="schedfrom-error"></span>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label for="inputTime"><b>To: </b></label>
                            <input type="time" id="sched_to" class="form-control">
                        </div>
                        <span class="schedto-error"></span>
                    </div>
                </div>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-danger" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-outline-primary" id="btn-schedule">Save</button>
            </div>
            </form>
        </div>
    </div>
</div>
<script type="text/javascript">
    document.addEventListener('DOMContentLoaded', () => {
        let btn = document.querySelector('#btn-schedule');
        btn.addEventListener('click', (e) => {
            e.preventDefault();

            const emp_id = $('#emp_id option:selected').val();
            console.log(emp_id);

            const sched_from = document.querySelector('input[id=sched_from]').value;
            console.log(sched_from);

            const sched_to = document.querySelector('input[id=sched_to]').value;
            console.log(sched_to);

            var data = new FormData(this.form);

            data.append('emp_id', emp_id);
            data.append('sched_from', sched_from);
            data.append('sched_to', sched_to);

            function isValidEmp() {
                      if ($("#emp_id").val() === "") {
                           $("#emp_id").addClass("is-invalid");
                           $(".emp-error").html('Please select Employee Name');
                           $(".emp-error").css({"color":"red","font-size":"14px"});
                          return false;
                      } else {
                          $("#emp_id").removeClass("is-invalid").addClass("is-valid");
                          $(".emp-error").css({"display":"none"});
                          return true;
                      }
                  };
 
              function isValidSchedFrom() {
                      if ($("#sched_from").val() === "") {
                           $("#sched_from").addClass("is-invalid");
                           $(".schedfrom-error").html('Required Schedule From');
                           $(".schedfrom-error").css({"color":"red","font-size":"14px"});
                          return false;
                      } else {
                           $("#sched_from").removeClass("is-invalid").addClass("is-valid");
                           $(".schedfrom-error").css({"display":"none"});
                          return true;
                      }
                  };
                    
              function isValidSchedTo() {
                      if ($("#sched_to").val() === "") {
                           $("#sched_to").addClass("is-invalid");
                           $(".schedto-error").html('Required Schedule To');
                           $(".schedto-error").css({"color":"red","font-size":"14px"});
                          return false;
                      } else {
                           $("#sched_to").removeClass("is-invalid").addClass("is-valid");
                           $(".schedto-error").css({"display":"none"});
                          return true;
                      }
                  };  


            isValidEmp();
            isValidSchedFrom();
            isValidSchedTo();

            if (isValidEmp() === true && isValidSchedFrom() === true && isValidSchedTo() === true) {

                $.ajax({
                    url: '../config/init/add_schedule.php',
                    type: "POST",
                    data: data,
                    processData: false,
                    contentType: false,
                    async: false,
                    cache: false,
                    success: function(response) {
                         $.toast({
                                heading: 'Success',
                                text: 'Added Schedule Successfully.',
                                showHideTransition: 'slide',
                                icon: 'success',
                                position: 'bottom-right',
                                hideAfter: 2000  
                            })
                         setTimeout(function () {  
                           location.reload(true);
                         }, 2500);
                          
                    },
                    error: function(response) {
                        console.log("Failed");
                    }
                });
            }

        });
    });
</script>