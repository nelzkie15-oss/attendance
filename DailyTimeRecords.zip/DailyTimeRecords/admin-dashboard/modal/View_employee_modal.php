<div class="modal" id="viewemployee-modal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content ">
            <div class="modal-header">
                <h5 class="modal-title"><i class="bi bi-plus-circle"></i> View Employee</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="form-group">
                    <center>
                        <div class="file-uploader">
                            <label name="upload-label" class="upload-img-btn" style="border-style: dashed;">
                                <img class="preview" id="view_images" src="" style="width:150px!important;"  />
                            </label>
                        </div>
                    <span class="pic-error"></span>

                    </center>
                </div>
                <div class="row">
                    <div class="col-lg-3 mt-2">
                        <div class="form-group">
                            <label for="inputTime"><b>Employee ID No.:</b></label>
                            <input type="text" id="view_empidno" class="form-control" autocomplete="off" readonly="">
                            <span class="empno-error"></span>
                        </div>
                    </div>
                    <div class="col-lg-3 mt-2">
                        <div class="form-group">
                            <label for="inputTime"><b>First Name:</b></label>
                            <input type="text" id="view_firstname" class="form-control" autocomplete="off" readonly="">
                            <span class="fname-error"></span>
                        </div>
                    </div>
                    <div class="col-lg-3 mt-2">
                        <div class="form-group">
                            <label for="inputTime"><b>Middle Name:</b></label>
                            <input type="text" id="view_middlename" class="form-control" placeholder="(Optionnal)" autocomplete="off" readonly="">
                            <span class=""></span>
                        </div>
                    </div>
                    <div class="col-lg-3 mt-2">
                        <div class="form-group">
                            <label for="inputTime"><b>Last Name: </b></label>
                            <input type="text" id="view_lastname" class="form-control" autocomplete="off" readonly="">
                            <span class="lname-error"></span>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-lg-3 mt-2">
                        <div class="form-group">
                            <label for="inputTime"><b>Date of Birth:</b></label>
                            <input type="date"  id="view_dateofbirth" class="form-control" autocomplete="off" readonly="">
                            <span class="dbirth-error"></span>
                        </div>
                    </div>
                    <div class="col-lg-3 mt-2">
                        <div class="form-group">
                            <label for="inputTime"><b>Contact Number:</b></label>
                            <input type="text" id="view_contactnumber" class="form-control" minlength="11" maxlength="11" autocomplete="off" readonly="">
                            <span class="cnumber-error"></span>
                        </div>
                    </div>
                    <div class="col-lg-6 mt-2">
                        <div class="form-group">
                            <label for="inputTime"><b>Complete Address: </b></label>
                            <input type="text" id="view_completeaddress" class="form-control" autocomplete="off" readonly="">
                            <span class="caddress-error"></span>
                        </div>
                    </div>
                </div>


                <div class="row">
                    <div class="col-lg-3 mt-2">
                        <div class="form-group">
                            <label for="inputTime"><b>Gender: </b></label>
                            <select class="form-control" id="view_gender"  autocomplete="off" readonly="">
                                <option value="">&larr; Select Gender &rarr;</option>
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                            </select>
                            <span class="gen-error"></span>
                        </div>
                    </div>
                    <div class="col-lg-3 mt-2">
                        <div class="form-group">
                            <label for="inputTime"><b>Email: </b></label>
                            <input type="email" id="view_email" class="form-control" placeholder="(Optionnal)" autocomplete="off" readonly="">
                            <span class=""></span>
                        </div>
                    </div>
                    <div class="col-lg-3 mt-2">
                        <div class="form-group">
                            <label for="inputTime"><b>Daily Rate:</b></label>
                            <input type="text" id="view_dailyrate" class="form-control" autocomplete="off" readonly="">
                            <span class="drate-error"></span>
                        </div>
                    </div>
                    <div class="col-lg-3 mt-2">
                        <div class="form-group">
                            <label for="inputTime"><b>Monthly Rate:</b></label>
                            <input type="text" id="view_mothlyrate" class="form-control" autocomplete="off" readonly="">
                            <span class="mrate-error"></span>
                        </div>
                    </div>

                </div>

                <div class="row">
                    <div class="col-lg-4 mt-2">
                        <div class="form-group">
                            <label for="inputTime"><b>SSS #: </b></label>
                            <input type="text" id="view_sssno" class="form-control" autocomplete="off" readonly="">
                            <span class="sssno-error"></span>
                        </div>
                    </div>
                    <div class="col-lg-4 mt-2">
                        <div class="form-group">
                            <label for="inputTime"><b>PhilHealth #:</b></label>
                            <input type="text" id="view_philHealth" class="form-control" autocomplete="off" readonly="">
                            <span class="phil-error"></span>
                        </div>
                    </div>
                    <div class="col-lg-4 mt-2">
                        <div class="form-group">
                            <label for="inputTime"><b>Pag-ibig #:</b></label>
                            <input type="text" id="view_pagibig" class="form-control" autocomplete="off" readonly="">
                            <span class="ibig-error"></span>
                        </div>
                    </div>

                </div>
                <div class="row">
                    <div class="col-lg-4 mt-2">
                        <div class="form-group">
                            <label for="inputTime"><b>Designation: </b></label>
                            <input type="text" id="view_designation" class="form-control" autocomplete="off" readonly="">
                            <span class="desig-error"></span>
                        </div>
                    </div>
                    <div class="col-lg-4 mt-2">
                        <div class="form-group">
                            <label for="inputTime"><b>Department: </b></label>
                            <select class="form-control" id="view_departmentid"  autocomplete="off" readonly="">
                                <option value="">&larr; Select Department &rarr;</option>
                                <?php
                                 require_once "../config/DTR_class.php";
                                  $conn = new Attendance();
                                  $depts = $conn->FetchDepartment();
                                 foreach ($depts as $row) { ?>
                                  <option value="<?php echo htmlentities($row['department_id']); ?>"><?php echo htmlentities($row['department_name']); ?></option>
                                <?php } ?>
                            </select>
                            <span class="dept-error"></span>
                        </div>
                    </div>
                    <div class="col-lg-4 mt-2">
                        <div class="form-group">
                            <label for="inputTime"><b>Date Hire:</b></label>
                            <input type="date" id="view_datehire" class="form-control" autocomplete="off" readonly="">
                            <span class="dhire-error"></span>
                        </div>
                    </div>

                </div>

                <div class="row">
                    <div class="col-lg-4 mt-2">
                        <div class="form-group">
                            <label for="inputTime"><b>Username: </b></label>
                            <input type="text" id="view_username" class="form-control" autocomplete="off" readonly="">
                            <span class="uname-error"></span>
                        </div>
                    </div>
                    <div class="col-lg-4 mt-2">
                        <div class="form-group">
                            <label for="inputTime"><b>Password:</b></label>
                            <input type="text" id="view_password" class="form-control" autocomplete="off" readonly="">
                            <span class="pass-error"></span>
                        </div>
                    </div>

                    <div class="col-lg-4 mt-2">
                        <div class="form-group">
                            <label for="inputTime"><b>Status: </b></label>
                            <select class="form-control" id="view_empstatus" autocomplete="off" readonly="">
                                <option value="">&larr; Select Status &rarr;</option>
                                <option value="Probationary">Probationary</option>
                                <option value="Regular">Regular</option>
                             </select>
                          <span class="dhire-error"></span>
                        </div>
                    </div>
                </div>


            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-danger" data-bs-dismiss="modal">Close</button>
              <!--   <button type="button" class="btn btn-outline-primary" id="btn-employee">Save</button> -->
            </div>
        </div>
    </div>
</div>
