<div class="modal" id="editdepartment-modal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="bi bi-plus-circle"></i> Edit Department</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST">
            <div class="modal-body">
                <div class="col-lg-12 mb-1">
                    <div class="form-group">
                        <label for="inputTime"><b>Department Name:</b></label>
                        <input type="text" id="edit_departmentname" class="form-control" autocomplete="off">
                        <span class="deptname-error"></span>
                    </div>
                </div>
                <div class="col-lg-12">
                    <div class="form-group">
                        <label for="inputTime"><b>Department Description: </b></label>
                        <textarea type="text" id="edit_departmentdescription" class="form-control" autocomplete="off"></textarea>
                        <span class="deptdesc-error"></span>
                    </div>
                </div>
                
            </div>
            <div class="modal-footer">
                <input type="hidden" name="" id="edit_departmentid">
                <button type="button" class="btn btn-outline-danger" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-outline-primary" id="btn-editdepartment">Update</button>
            </div>
           </form>
        </div>
    </div>
</div>

<script type="text/javascript">
    document.addEventListener('DOMContentLoaded', () => {
        let btn = document.querySelector('#btn-editdepartment');
        btn.addEventListener('click', (e) => {
            e.preventDefault();


            const department_name = document.querySelector('input[id=edit_departmentname]').value;
            console.log(department_name);

            const department_description = document.querySelector('textarea[id=edit_departmentdescription]').value;
            console.log(department_description);

            const department_id = document.querySelector('input[id=edit_departmentid]').value;
            console.log(department_id);

            var data = new FormData(this.form);

            data.append('department_name', department_name);
            data.append('department_description', department_description);
            data.append('department_id', department_id);


            function isValidDepartmentName2() {
                var pattern = /^[a-zA-Z \s]+$/;
                var department_name = $("#edit_departmentname").val();
                if (pattern.test(department_name) && department_name !== "") {
                    $("#edit_departmentname").removeClass("is-invalid").addClass("is-valid");
                    $(".deptname-error").html('Please input Character');
                     $(".deptname-error").css({
                        "color": "green",
                        "font-size": "14px",
                        "display": "none"
                    });
                    return true;
                } else if (department_name === "") {
                    $("#edit_departmentname").removeClass("is-valid").addClass("is-invalid");
                    $(".deptname-error").html('Required Department Name');
                    $(".deptname-error").css({
                        "color": "red",
                        "font-size": "14px"
                    });
                } else {
                    $("#edit_departmentname").removeClass("is-valid").addClass("is-invalid");
                     $(".deptname-error").html('Please input Character only');
                    $(".deptname-error").css({
                        "color": "red",
                        "font-size": "14px",
                        "display": "block"
                    });
                }
            };


            function isValidDepartmentDecs2() {
                var pattern = /^[a-zA-Z \s]+$/;
                var department_description = $("#edit_departmentdescription").val();
                if (pattern.test(department_description) && department_description !== "") {
                    $("#edit_departmentdescription").removeClass("is-invalid").addClass("is-valid");
                    $(".deptdesc-error").css({
                        "color": "green",
                        "font-size": "14px",
                        "display": "none"
                    });
                    return true;
                } else if (department_description === "") {
                    $("#edit_departmentdescription").removeClass("is-valid").addClass("is-invalid");
                   $(".deptdesc-error").html('Required Department Description');
                    $(".deptdesc-error").css({
                        "color": "red",
                        "font-size": "14px"
                    });
                } else {
                    $("#edit_departmentdescription").removeClass("is-valid").addClass("is-invalid");
                    $(".deptdesc-error").html('Please input Character only');
                    $(".deptdesc-error").css({
                        "color": "red",
                        "font-size": "14px",
                        "display": "block"
                    });
                }
            };


            isValidDepartmentName2();
            isValidDepartmentDecs2();

            if (isValidDepartmentName2() === true && isValidDepartmentDecs2() === true) {

                $.ajax({
                    url: '../config/init/edit_department.php',
                    type: "POST",
                    data: data,
                    processData: false,
                    contentType: false,
                    async: false,
                    cache: false,
                    success: function(response) {
                         $.toast({
                                heading: 'Success',
                                text: 'Update Department Successfully.',
                                showHideTransition: 'slide',
                                icon: 'success',
                                position: 'bottom-right',
                                hideAfter: 2000  
                            })
                         setTimeout(function () {  
                           location.reload(true);
                         }, 2500);
                          
                    },
                    error: function(response) {
                        console.log("Failed");
                    }
                });
            }

        });
    });
</script>