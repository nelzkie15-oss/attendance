<div class="modal" id="department-modal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="bi bi-plus-circle"></i> New Department</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST">
            <div class="modal-body">
                <div class="col-lg-12 mb-1">
                    <div class="form-group">
                        <label for="inputTime"><b>Department Name:</b></label>
                        <input type="text" id="department_name" class="form-control" autocomplete="off">
                        <span class="deptname-error"></span>
                    </div>
                </div>
                <div class="col-lg-12">
                    <div class="form-group">
                        <label for="inputTime"><b>Department Description: </b></label>
                        <textarea type="text" id="department_description" class="form-control" autocomplete="off"></textarea>
                        <span class="deptdesc-error"></span>
                    </div>
                </div>
                
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-danger" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-outline-primary" id="btn-department">Save</button>
            </div>
           </form>
        </div>
    </div>
</div>

<script type="text/javascript">
    document.addEventListener('DOMContentLoaded', () => {
        let btn = document.querySelector('#btn-department');
        btn.addEventListener('click', (e) => {
            e.preventDefault();


            const department_name = document.querySelector('input[id=department_name]').value;
            console.log(department_name);

            const department_description = document.querySelector('textarea[id=department_description]').value;
            console.log(department_description);

            var data = new FormData(this.form);

            data.append('department_name', department_name);
            data.append('department_description', department_description);


            function isValidDepartmentName() {
                var pattern = /^[a-zA-Z \s]+$/;
                var department_name = $("#department_name").val();
                if (pattern.test(department_name) && department_name !== "") {
                    $("#department_name").removeClass("is-invalid").addClass("is-valid");
                    $(".deptname-error").css({
                        "color": "green",
                        "font-size": "14px",
                        "display": "none"
                    });
                    return true;
                } else if (department_name === "") {
                    $("#department_name").removeClass("is-valid").addClass("is-invalid");
                    $(".deptname-error").html('Required Department Name');
                    $(".deptname-error").css({
                        "color": "red",
                        "font-size": "14px"
                    });
                } else {
                    $("#department_name").removeClass("is-valid").addClass("is-invalid");
                    $(".deptname-error").html('Please input Character only');
                    $(".deptname-error").css({
                        "color": "red",
                        "font-size": "14px",
                        "display": "block"
                    });
                }
            };


            function isValidDepartmentDecs() {
                var pattern = /^[a-zA-Z \s]+$/;
                var department_description = $("#department_description").val();
                if (pattern.test(department_description) && department_description !== "") {
                    $("#department_description").removeClass("is-invalid").addClass("is-valid");
                    $(".deptdesc-error").css({
                        "color": "green",
                        "font-size": "14px",
                        "display": "none"
                    });
                    return true;
                } else if (department_description === "") {
                    $("#department_description").removeClass("is-valid").addClass("is-invalid");
                    $(".deptdesc-error").html('Required Department Description');
                    $(".deptdesc-error").css({
                        "color": "red",
                        "font-size": "14px"
                    });
                } else {
                    $("#department_description").removeClass("is-valid").addClass("is-invalid");
                    $(".deptdesc-error").html('Please input Character only');
                    $(".deptdesc-error").css({
                        "color": "red",
                        "font-size": "14px",
                        "display": "block"
                    });
                }
            };


            isValidDepartmentName();
            isValidDepartmentDecs();

            if (isValidDepartmentName() === true && isValidDepartmentDecs() === true) {

                $.ajax({
                    url: '../config/init/add_department.php',
                    type: "POST",
                    data: data,
                    processData: false,
                    contentType: false,
                    async: false,
                    cache: false,
                    success: function(response) {
                         $.toast({
                                heading: 'Success',
                                text: 'Added Department Successfully.',
                                showHideTransition: 'slide',
                                icon: 'success',
                                position: 'bottom-right',
                                hideAfter: 2000  
                            })
                         setTimeout(function () {  
                           location.reload(true);
                         }, 2500);
                          
                    },
                    error: function(response) {
                        console.log("Failed");
                    }
                });
            }

        });
    });
</script>