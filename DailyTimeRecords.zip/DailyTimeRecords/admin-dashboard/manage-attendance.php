<?php include 'headerANDsidebar/menu.php';?>

<main id="main" class="main">

    <div class="card">
        <div class="card-body">
            <nav>
                <ol class="breadcrumb pt-4">
                    <li class="breadcrumb-item"><a href="home"><i class="bi bi-house-door"></i> Home</a></li>
                    <li class="breadcrumb-item active"><i class="bi bi-clock"></i> Manage Attendance</li>
                </ol>
            </nav>
        </div>
    </div>
  <div id="loader"></div>
    <section class="section dashboard">
        <!-- Recent Sales -->
        <div class="row">
            <div class="col-md-12">
                <div class="card recent-sales overflow-auto">

                    <div class="card-body">
                 <!--        <div class="row">
                            <div class="col-4">
                                <h5 class="card-title">Manage Attendance</h5>
                            </div>
                            <div class="col-8"><button class="btn btn-outline-success mt-3" style="float: right;" value="Add Department" data-bs-toggle="modal" data-bs-target="#department-modal"><i class="bi bi-plus-circle"></i> Add Attendance</button></div>
                        </div> -->
                        <hr style="border:2px solid black">
                        </hr>
                       <div class="table-responsive">
                        <table class="table table-striped datatable">
                                    <thead>
                                        <tr>
                                            <th scope="col">PHOTO</th>
                                            <th scope="col">EMPLOYEE NAME</th>
                                            <th scope="col">POSITION</th>
                                            <th scope="col">DEPARTMENT</th>

                                            <th scope="col">ACTION</th>

                                        </tr>
                                    </thead>
                                    <tbody>
                                          <?php foreach ($dtr as $row) {
                                             $pic = htmlentities($row['images']);
                                              $image = $pic ? $pic :"../uploads/default_img/191688-200.png";//sets your image

                                           ?>
                                          <tr>
                                                <td>
                                                    <center><img src="<?php echo $image;?>" width="50px;" height="50px"></center>
                                                </td>
                                                <td><?= htmlentities($row['employee_name']); ?></td>
                                                <td><?= htmlentities($row['designation']); ?></td>
                                                <td><?= htmlentities($row['department_name']); ?></td>

                                                <td width="10%"> <center><button class="btn btn-outline-primary btn-sm btn_views" data-bs-toggle="modal"  data-bs-target="#viewAttendance-modal<?php echo htmlentities($row['emp_id']); ?>"  data-views="<?= htmlentities($row['emp_id']); ?>"><i class="bi bi-plus-eye"></i> View</button> </center><?php include 'modal/View_attendance_modal.php';?></td>
                                            </tr>
                                         <?php } ?>
                                    </tbody>
                                </table>
                      </div>
                    </div>
                </div>
            </div><!-- End Recent Sales -->

        </div>
        </div>
        </div>
    </section>

</main>

<!-- <?php //include 'modal/Edit_department_modal.php';?>
<?php //include 'modal/Delete_department_modal.php';?> -->
<?php include 'footer/footer.php';?>

       <script>
       $(document).ready(function() {   
           load_data();    
           var count = 1; 
           function load_data() {
               $(document).on('click', '.btn-del', function() {
                  $('#deldepartment-modal').modal('show');
                    var department_id = $(this).data("del");
                      get_delId(department_id); //argument    
             
               });
            }

             function get_delId(department_id) {
                  $.ajax({
                      type: 'POST',
                      url: '../config/init/row_depertment.php',
                      data: {
                          department_id: department_id
                      },
                      dataType: 'json',
                      success: function(response2) {
                      $('#delete_departmentid').val(response2.department_id);
                      $('#delete_departmentname').val(response2.department_name);
      
                   }
                });
             }
       
       });
        
 </script>
</body>

</html>