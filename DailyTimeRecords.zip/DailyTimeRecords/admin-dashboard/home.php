
 <?php include 'headerANDsidebar/menu.php';?>
    <main id="main" class="main">

        <div class="pagetitle">
            <h1>Dashboard</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                    <li class="breadcrumb-item active">Dashboard</li>
                </ol>
            </nav>
        </div><!-- End Page Title -->

        <section class="section dashboard">
            <div class="row">

                <!-- Left side columns -->

                <div class="row">


                    <!-- Sales Card -->
                    <div class="col-xxl-4 col-md-3">
                        <div class="card info-card sales-card">

  
                            <div class="card-body">
                                <h5 class="card-title">Employees</h5>

                                <div class="d-flex align-items-center">
                                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                        <i class="bi bi-person-square"></i>
                                    </div>
                                    <?php
                                      require_once "../config/DTR_class.php";
                                      $conn = new Attendance();
                                      $Emps = $conn->count_Employees();
                                   foreach ($Emps as $row) { ?>
                                    <div class="ps-3">
                                        <h6><?php echo htmlentities($row['emp_id']); ?></h6>
                                       <?php } ?>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div><!-- End Sales Card -->


                    <!-- Revenue Card -->
                    <div class="col-xxl-4 col-md-3">
                        <div class="card info-card revenue-card">

       

                            <div class="card-body">
                                <h5 class="card-title">Attendance</h5>

                                <div class="d-flex align-items-center">
                                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                        <i class="bi bi-clock"></i>
                                    </div>
                                   <?php
                                      require_once "../config/DTR_class.php";
                                      $conn = new Attendance();
                                      $attend = $conn->count_Attendance();
                                   foreach ($attend as $row) { ?>
                                    <div class="ps-3">
                                        <h6><?php echo htmlentities($row['attendance_id']); ?></h6>
                                       <?php } ?>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div><!-- End Revenue Card -->

                    <!-- Sales Card -->
                    <div class="col-xxl-4 col-md-3">
                        <div class="card info-card sales-card">

     

                            <div class="card-body">
                                <h5 class="card-title">Department</h5>

                                <div class="d-flex align-items-center">
                                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                        <i class="bi bi-building"></i>
                                    </div>
                                    <?php
                                      require_once "../config/DTR_class.php";
                                      $conn = new Attendance();
                                      $dept = $conn->count_Department();
                                   foreach ($dept as $row) { ?>
                                    <div class="ps-3">
                                        <h6><?php echo htmlentities($row['department_id']); ?></h6>
                                       <?php } ?>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div><!-- End Sales Card -->


                    <!-- Revenue Card -->
                    <div class="col-xxl-4 col-md-3">
                        <div class="card info-card revenue-card">

       

                            <div class="card-body">
                                <h5 class="card-title">Leave</h5>

                                <div class="d-flex align-items-center">
                                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                        <i class="bi bi-person-x"></i>
                                    </div>
                                    <div class="ps-3">
                                        <h6>0</h6>


                                    </div>
                                </div>
                            </div>

                        </div>
                    </div><!-- End Revenue Card -->

                </div>

                <!-- Recent Sales -->
                <div class="row">

                    <div class="col-md-6">

                        <div class="card recent-sales overflow-auto">



                            <div class="card-body">
                                <h5 class="card-title">Attendance <span>| Today</span></h5>

                               <div class="table-responsive">
                                <table class="table table-striped datatable">
                                    <thead>
                                        <tr>
                                            <th scope="col">PHOTO</th>
                                            <th scope="col">EMPLOYEE NO.</th>
                                            <th scope="col">TIME IN</th>
                                            <th scope="col">TIME OUT</th>
                                            <th scope="col">LOG DATE</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                          <?php 
                                             require_once "../config/DTR_class.php";
                                             $conn = new Attendance();
                                             $dtr = $conn->FetchAttendanceAdmin();
                                          ?>
                                          <?php foreach ($dtr as $row) {
                                             $pic = htmlentities($row['images']);
                                              $image = $pic ? $pic :"../uploads/default_img/191688-200.png";//sets your image

                                           ?>
                                          <tr align="center">
                                                <td>
                                                    <center><img src="<?php echo $image;?>" width="50px;" height="50px"></center>
                                                </td>
                                                <td><?= htmlentities($row['empid_no']); ?></td>
                                                <td><?= date("g:i a", strtotime(htmlentities($row['time_in']))); ?></td>
                                                <td><?= date("g:i a", strtotime(htmlentities($row['time_out']))); ?></td>
                                                <td><?= htmlentities(date("M d, Y",strtotime($row['logdate']))); ?></td>
                                            </tr>
                                         <?php } ?>
                                    </tbody>
                                </table>
                                </div>
                            </div>

                        </div>
                    </div><!-- End Recent Sales -->


                    <div class="col-md-6">

                        <div class="card recent-sales overflow-auto">

             
 
                            <div class="card-body">
                                <h5 class="card-title">New Members <span>| Today</span></h5>
                                <div class="table-responsive">
                                <table class="table table-striped datatable">
                                    <thead>
                                        <tr>
                                            <th scope="col">Employee No.</th>
                                            <th scope="col">Employee Name</th>
                                            <th scope="col">Designation</th>
                                            <th scope="col">Emp Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                       <?php 
                                             require_once "../config/DTR_class.php";
                                             $conn = new Attendance();
                                             $emp = $conn->FetchAllEmpAdmin();
                                          ?>
                                          <?php foreach ($emp as $row) { ?>
                                        <tr>
                                             <td><?= htmlentities($row['empid_no']); ?></td>
                                             <td><?= htmlentities($row['employee_name']); ?></td>
                                             <td><?= htmlentities($row['designation']); ?></td>
                                             <td><?= htmlentities($row['emp_status']); ?></td>

                                        </tr>
                                       <?php } ?>
                   
                                    </tbody>
                                </table>
                               </div>
                            </div>

                        </div>
                    </div><!-- End Recent Sales -->

                </div>
            </div>
        </section>

    </main>

 <?php include 'footer/footer.php';?>

</body>

</html>