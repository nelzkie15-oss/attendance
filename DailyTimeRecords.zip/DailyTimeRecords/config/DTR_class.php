 <?php

     require 'config.php'; 

  
     class Attendance
     {
      private $server = DB_HOST;
      private $user   = DB_USER;
      private $pass   = DB_PASS;
      private $db     = DB_NAME;
      private $pdo; 

      public function __construct()
      {
           $this->db_connect();
      }

   public function db_connect()//connection OOP PDO
        {
        	$this->pdo = null;
          try{
              $this->pdo = new PDO("mysql:host=".$this->server.";dbname=".$this->db, $this->user, $this->pass);
             	$this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
              if(!$this->pdo){
              	return false;
              }	
          }catch(PDOException $e){
             echo $e->getMessage();
          }
        }


      ///////////////////////Fetch Account//////////////////////////

     public function fetch_Adminsession($AdminID_session){
         $query = $this->pdo->prepare("SELECT * FROM  tbl_admin WHERE  admin_id = ? ORDER BY admin_id  DESC");
          $query->execute(array($AdminID_session));
          return $query->fetchAll();
      }

 ///////////////////////end Fetch Account/////////////////////

/////////////////////// login User///////////////////////////

     public function login_user($username, $password, $type) {
        
         session_start();

         $stmt1 = $this->pdo->prepare("SELECT * FROM tbl_admin WHERE username = :uname AND password= :upass  AND type = :stat");
         $stmt1->execute(array(':uname' => $username, ':upass' => $password, ':stat' => $type));
         $row1=$stmt1->fetch(PDO::FETCH_ASSOC);

         $stmt2 = $this->pdo->prepare("SELECT * FROM tbl_employee WHERE username = :uname AND password= :upass  AND type = :stat AND status = 'Active'");
         $stmt2->execute(array(':uname' => $username, ':upass' => $password, ':stat' => $type));
         $row2=$stmt2->fetch(PDO::FETCH_ASSOC);

          if ($stmt1->rowCount() > 0){
           
              $_SESSION['user_no']   = htmlentities($row1['admin_id']);
              $_SESSION['logged_in'] = true;
              echo '1';

          }elseif($stmt2->rowCount() > 0){
           
              $_SESSION['user_no2']   = htmlentities($row2['emp_id']);
              $_SESSION['logged_in'] = true;
              echo '2';
            
                exit();
          }else{
              //echo '0';
             echo "<div class='alert alert-danger'> <i class='fa fa-times'></i>  Incorrect Username or Password</div>";
          }
      }

      ///////////////////////end login User//////////////////////////


     ///////////////////////Add department//////////////////////////

      public function add_department($department_name, $department_description){

           $stmt = $this->pdo->prepare("INSERT INTO  `tbl_department` (`department_name`,`department_description`) VALUES(?,?)");
           $true = $stmt->execute([$department_name, $department_description]);
           if ($true == true) {
               return true;
             } else {
               return false;
          }
        }
    ///////////////////////end Add department//////////////////////////

     ///////////////////////Fetch Department//////////////

     public function FetchDepartment(){
         $query = $this->pdo->prepare("SELECT * FROM `tbl_department` ORDER BY department_id DESC");
          $query->execute(array());
          return $query->fetchAll();
      }

     ///////////////////////end Fetch Department////////////

     /////////////////////// Fetch row Department////////////

        public function department_row($id) {

            $stmt = $this->pdo->prepare("SELECT * FROM `tbl_department` WHERE department_id  = ?");
            $stmt->execute([$id]);
            $row = $stmt->fetch();
            echo json_encode($row);
       }
    ///////////////////////end Fetch row Department////////////

   /////////////////////// Edit Department////////////

        public function edit_department($department_name, $department_description, $department_id) {

          $sql = "UPDATE `tbl_department` SET  `department_name` = ?, `department_description` = ? WHERE department_id = ?";
          $update = $this->pdo->prepare($sql)->execute([$department_name, $department_description, $department_id]);
            if ($update == true) {
                return true;
             } else {
                return false;
           }

       }
    ///////////////////////end Edit Department////////////


    /////////////////////// Delete Department////////////////

     public function delete_department($department_id){

          $sql = "DELETE FROM `tbl_department` WHERE department_id = ?";
          $delete = $this->pdo->prepare($sql)->execute([$department_id]);
            if ($delete == true) {
                return true;
            } else {
                return false;
            }
        }

  ///////////////////////end Delete Department////////////////

   ///////////////////////Add Schedule//////////////////////////

        public function add_schedule($emp_id, $sched_from, $sched_to){

           $stmt = $this->pdo->prepare("INSERT INTO  `tbl_schedule` (`emp_id`,`sched_from`, `sched_to`) VALUES(?,?,?)");
           $true = $stmt->execute([$emp_id, $sched_from, $sched_to]);
           if ($true == true) {
               return true;
             } else {
               return false;
          }
        }
    ///////////////////////end Add Schedule//////////////////////////

          ///////////////////////Fetch Schedule//////////////

     public function FetchSchedule(){
         $query = $this->pdo->prepare("SELECT *, CONCAT(e.last_name, ', ' ,e.first_name, ' ' ,e.middle_name) as employee_name FROM `tbl_schedule` s LEFT JOIN tbl_employee e ON s.emp_id = e.emp_id ORDER BY s.schedule_id  DESC");
          $query->execute(array());
          return $query->fetchAll();
      }

     ///////////////////////end Fetch Schedule////////////

        /////////////////////// Fetch row Schedule////////////

        public function dschedule_row($id) {

            $stmt = $this->pdo->prepare("SELECT * FROM `tbl_schedule` WHERE schedule_id  = ?");
            $stmt->execute([$id]);
            $row = $stmt->fetch();
            echo json_encode($row);
       }
    ///////////////////////end Fetch row Schedule////////////

       /////////////////////// Edit Schedule////////////

        public function edit_schedule($emp_id, $sched_from, $sched_to, $schedule_id) {

          $sql = "UPDATE `tbl_schedule` SET  `emp_id` = ?, `sched_from` = ?, `sched_to` = ? WHERE schedule_id = ?";
          $update = $this->pdo->prepare($sql)->execute([$emp_id, $sched_from, $sched_to, $schedule_id]);
            if ($update == true) {
                return true;
             } else {
                return false;
           }

       }
    ///////////////////////end Edit Schedule////////////

      /////////////////////// Delete Schedule////////////////

     public function delete_schedule($schedule_id){

          $sql = "DELETE FROM `tbl_schedule` WHERE schedule_id = ?";
          $delete = $this->pdo->prepare($sql)->execute([$schedule_id]);
            if ($delete == true) {
                return true;
            } else {
                return false;
            }
        }

  ///////////////////////end Delete Schedule////////////////

       ///////////////////////Add Employee//////////////////////////

        public function add_employee($emp_pic, $empid_no, $first_name, $middle_name, $last_name, $date_ofbirth, $contact_number, $complete_address, $gender, $email, $daily_rate, $mothly_rate, $sss_no, $philHealth, $pag_ibig, $designation, $department, $date_hire, $username, $password, $emp_status, $codeContents){
        
          $stat = "Active";
          $type = "Employee";
         
           $stmt = $this->pdo->prepare("INSERT INTO  `tbl_employee` (`images`, `empid_no`, `first_name`, `middle_name`, `last_name`, `date_ofbirth`, `contact_number`, `complete_address`, `gender`, `email`, `daily_rate`, `mothly_rate`, `sss_no`, `philHealth`, `pag_ibig`, `designation`, `department_id`, `date_hire`, `username`, `password`, `emp_status`, `qr_code`, `status`,`type`) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
           $true = $stmt->execute([$emp_pic, $empid_no, $first_name, $middle_name, $last_name, $date_ofbirth, $contact_number, $complete_address, $gender, $email, $daily_rate, $mothly_rate, $sss_no, $philHealth, $pag_ibig, $designation, $department, $date_hire, $username, $password, $emp_status, $codeContents, $stat, $type]);
           if ($true == true) {
               return true;
             } else {
               return false;
          }
        }
    ///////////////////////end Add Employee//////////////////////////


   ///////////////////////Fetch Employees//////////////

     public function FetchEmployees(){
         $query = $this->pdo->prepare("SELECT *, CONCAT(a.last_name, ', ' ,a.first_name, ' ' ,a.middle_name) as employee_name FROM `tbl_employee` a
                                       LEFT JOIN tbl_department d ON a.department_id = d.department_id  ORDER BY a.emp_id  DESC");
          $query->execute(array());
          return $query->fetchAll();
      }

     ///////////////////////end Fetch Employees////////////

     /////////////////////// Scan QR Code Attendance////////////
     public function scan_qrcode($emp) {


               date_default_timezone_set("asia/manila");
               $date = date('Y-m-d');
               $time =  date('H:i', strtotime("+0 HOURS"));
               $stat = 0;
               $stat2 = 1;

               $stmt1 = $this->pdo->prepare("SELECT * FROM tbl_employee WHERE qr_code = ?");
               $stmt1->execute([$emp]);
               $row_count = $stmt1->rowCount();
               $result = $stmt1->fetchAll();

               foreach ($result as $value) {
                 $empID = htmlentities($value['emp_id']);
               }

              if($row_count <= 0){
                  echo 2;

              }else{
              
                $stmt2 = $this->pdo->prepare("SELECT * FROM tbl_attendance WHERE employee_qrcode = ? AND logdate = ? AND status = '0' ORDER BY attendance_id DESC");
                $stmt2->execute([$emp, $date]);
                $row_count2 = $stmt2->rowCount();
                $result2 = $stmt2->fetchAll();

               foreach ($result2 as $value) {
                 $attendance_id = htmlentities($value['attendance_id']);
               }
              if($row_count2 > 0){
               
                $sql = "UPDATE tbl_attendance SET time_out = ?, status = '1', employee_qrcode = ? WHERE  attendance_id = ?";
                $stmt = $this->pdo->prepare($sql);
                $stmt->execute([$time, $emp, $attendance_id]);

                   echo 3;

              }else{

                  $stmt = $this->pdo->prepare("INSERT INTO tbl_attendance(employee_qrcode,time_in,logdate, status, emp_id) VALUES (?, ?, ?, ?, ?)");
                  $result = $stmt->execute([$emp, $time, $date, $stat, $empID]);

                  if($result === TRUE){
                    echo 1;

                  }else{
                     echo 4;  
                  }

               }

           }
        
         
       }
  ///////////////////////end Scan QR Code Attendance////////////

   ///////////////////////Fetch All Attendance//////////////

     public function FetchAttendance(){
         $query = $this->pdo->prepare("SELECT * FROM `tbl_attendance` a LEFT JOIN tbl_employee e ON a.emp_id = e.emp_id WHERE DATE(a.logdate) = CURDATE()  ORDER BY a.attendance_id  DESC");
          $query->execute(array());
          return $query->fetchAll();
      }

     ///////////////////////end Fetch All Attendance////////////

         ///////////////////////Fetch All Attendance (Admin Home)//////////////

     public function FetchAttendanceAdmin(){
         $query = $this->pdo->prepare("SELECT *,CONCAT(e.last_name, ', ' ,e.first_name, ' ' ,e.middle_name) as employee_name, count(e.emp_id) AS emp_ids
                                       FROM `tbl_attendance` a LEFT JOIN tbl_employee e ON a.emp_id = e.emp_id 
                                       LEFT JOIN tbl_department d ON d.department_id = e.department_id 
                                       GROUP BY a.emp_id ORDER BY a.attendance_id  DESC");
          $query->execute(array());
          return $query->fetchAll();
      }

     ///////////////////////end Fetch All Attendance (Admin Home)////////////

         ///////////////////////Fetch All Employee (Admin Home)//////////////

     public function FetchAllEmpAdmin(){
         $query = $this->pdo->prepare("SELECT *, CONCAT(last_name, ', ' ,first_name, ' ' ,middle_name) as employee_name  FROM tbl_employee  WHERE DATE(date_created) = CURDATE()  ORDER BY emp_id  DESC");
          $query->execute(array());
          return $query->fetchAll();
      }

     ///////////////////////end Fetch All Employee (Admin Home)////////////

     /////////////////////////////count Employees (Admin Home)/////////////////////////////

     public function count_Employees(){
        $query = $this->pdo->prepare("SELECT COUNT(emp_id) as emp_id FROM  tbl_employee");
                $query->execute(array());
                return $query->fetchAll();
        }

       /////////////////////////////count Employees (Admin Home)/////////////////////////////


     /////////////////////////////count Attendance (Admin Home)/////////////////////////////

     public function count_Attendance(){
        $query = $this->pdo->prepare("SELECT COUNT(attendance_id) as attendance_id FROM  tbl_attendance");
                $query->execute(array());
                return $query->fetchAll();
        }

       /////////////////////////////count Attendance (Admin Home)/////////////////////////////

       /////////////////////////////count Deprtment (Admin Home)/////////////////////////////

     public function count_Department(){
        $query = $this->pdo->prepare("SELECT COUNT(department_id) as department_id FROM  tbl_department");
                $query->execute(array());
                return $query->fetchAll();
        }

       /////////////////////////////count Deprtment (Admin Home)/////////////////////////////

           /////////////////////// Fetch row Employee////////////

        public function employee_row($id) {

            $stmt = $this->pdo->prepare("SELECT * FROM `tbl_employee` WHERE emp_id = ?");
            $stmt->execute([$id]);
            $row = $stmt->fetch();
            echo json_encode($row);
       }
    ///////////////////////end Fetch row Employee////////////


      /////////////////////// Edit Employee////////////

        public function edit_employee($empid_no, $first_name, $middle_name, $last_name, $date_ofbirth, $contact_number, $complete_address, $gender, $email, $daily_rate, $mothly_rate, $sss_no, $philHealth, $pag_ibig, $designation, $department, $date_hire, $username, $password, $emp_status, $emp_id) {

          $sql = "UPDATE `tbl_employee` SET  `empid_no` = ?, `first_name` = ?, `middle_name` = ?, `last_name` = ?, `date_ofbirth` = ?, `contact_number` = ?, `complete_address` = ?, `gender` = ?, `email` = ?, `daily_rate` = ?,  `mothly_rate` = ?, `sss_no` = ?, `philHealth` = ?, `pag_ibig` = ?, `designation` = ?, `department_id` = ?, `date_hire` = ?, `username` = ?, `password` = ?, `emp_status` = ? WHERE emp_id = ?";
          $update = $this->pdo->prepare($sql)->execute([$empid_no, $first_name, $middle_name, $last_name, $date_ofbirth, $contact_number, $complete_address, $gender, $email, $daily_rate, $mothly_rate, $sss_no, $philHealth, $pag_ibig, $designation, $department, $date_hire, $username, $password, $emp_status, $emp_id]);
            if ($update == true) {
                return true;
             } else {
                return false;
           }

       }
    ///////////////////////end Edit Employee////////////

       
      /////////////////////// Delete Employee////////////////

     public function delete_employee($emp_id){

          $sql = "DELETE FROM `tbl_employee` WHERE emp_id = ?";
          $delete = $this->pdo->prepare($sql)->execute([$emp_id]);
            if ($delete == true) {
                return true;
            } else {
                return false;
            }
        }

  ///////////////////////end Delete Employee////////////////



   ///////////////////////Fetch Employees(Admin modal Schedule)//////////////

     public function FetchEmployeesAdmin(){
         $query = $this->pdo->prepare("SELECT *, CONCAT(last_name, ', ' ,first_name, ' ' ,middle_name) as employee_name FROM `tbl_employee` ORDER BY emp_id  DESC");
          $query->execute(array());
          return $query->fetchAll();
      }

     ///////////////////////end Fetch Employees(Admin modal Schedule)////////////

        /////////////////////// Fetch row Employee Attendance////////////

        public function FetchEmpAttendance($getEmpId){

             $query = $this->pdo->prepare("SELECT * FROM `tbl_employee` e
                                           LEFT JOIN tbl_attendance a ON e.emp_id = a.emp_id 
                                           LEFT JOIN tbl_schedule s ON s.emp_id = e.emp_id 
                                           WHERE a.emp_id = ?");
             $query->execute(array($getEmpId));
                return $query->fetchAll();

       }
    ///////////////////////end Fetch row Employee Attendance////////////

          /////////////////////////////count Attendance per employee (Admin Home)/////////////////////////////

     public function Count_attendanceEmp($getEmpId){
        $query = $this->pdo->prepare("SELECT COUNT(attendance_id) as attendance_id FROM  tbl_attendance WHERE emp_id = ?");
                $query->execute(array($getEmpId));
                return $query->fetchAll();
        }

       /////////////////////////////count Attendance per employee(Admin Home)/////////////////////////////

  }
?>



