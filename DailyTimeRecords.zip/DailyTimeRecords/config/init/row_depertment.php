
<?php
  require_once "../../config/DTR_class.php";
  if(isset($_POST['department_id'])){ 	
 	 $conn = new Attendance();
	 $id = htmlspecialchars(strip_tags(stripslashes(trim($_POST['department_id']))));
	 $conn->department_row($id);
		
	}

?>

