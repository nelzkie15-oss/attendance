<?php
  require_once "../DTR_class.php";

	if(ISSET($_POST)){
		$conn = new Attendance();

		$schedule_id = htmlspecialchars(strip_tags(stripslashes(trim($_POST['schedule_id']))));
	
		$conn->delete_schedule($schedule_id);

	}

?>

