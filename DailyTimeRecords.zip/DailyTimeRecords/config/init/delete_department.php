<?php
  require_once "../DTR_class.php";

	if(ISSET($_POST)){
		$conn = new Attendance();

		$department_id = htmlspecialchars(strip_tags(stripslashes(trim($_POST['department_id']))));
	
		$conn->delete_department($department_id);

	}

?>

