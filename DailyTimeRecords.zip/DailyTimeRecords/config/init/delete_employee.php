<?php
  require_once "../DTR_class.php";

	if(ISSET($_POST)){
		$conn = new Attendance();

		$emp_id = htmlspecialchars(strip_tags(stripslashes(trim($_POST['emp_id']))));
	
		$conn->delete_employee($emp_id);

	}

?>

