<?php
  require_once "../DTR_class.php";

	if(ISSET($_POST)){
		$conn = new Attendance();

		$username = htmlspecialchars(strip_tags(stripslashes(trim($_POST['username']))));
		$password = htmlspecialchars(strip_tags(stripslashes(trim($_POST['password']))));
		$type = htmlspecialchars(strip_tags(stripslashes(trim($_POST['type']))));
	
	    $conn->login_user($username, $password, $type);
	}

?>

