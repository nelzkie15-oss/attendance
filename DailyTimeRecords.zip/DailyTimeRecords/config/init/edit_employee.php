<?php
  require_once "../DTR_class.php";

	if(ISSET($_POST)){
		$conn = new Attendance();


        $empid_no = htmlspecialchars(strip_tags(stripslashes(trim($_POST['empid_no']))));
		$first_name = htmlspecialchars(strip_tags(stripslashes(trim(ucfirst($_POST['first_name'])))));
		$middle_name = htmlspecialchars(strip_tags(stripslashes(trim(ucfirst($_POST['middle_name'])))));
		$last_name = htmlspecialchars(strip_tags(stripslashes(trim(ucfirst($_POST['last_name'])))));
		$date_ofbirth = htmlspecialchars(strip_tags(stripslashes(trim($_POST['date_ofbirth']))));
		$contact_number = htmlspecialchars(strip_tags(stripslashes(trim($_POST['contact_number']))));
		$complete_address = htmlspecialchars(strip_tags(stripslashes(trim(ucfirst($_POST['complete_address'])))));
		$gender = htmlspecialchars(strip_tags(stripslashes(trim($_POST['gender']))));
		$email = htmlspecialchars(strip_tags(stripslashes(trim($_POST['email']))));
		$daily_rate = htmlspecialchars(strip_tags(stripslashes(trim($_POST['daily_rate']))));
		$mothly_rate = htmlspecialchars(strip_tags(stripslashes(trim($_POST['mothly_rate']))));
		$sss_no = htmlspecialchars(strip_tags(stripslashes(trim($_POST['sss_no']))));
		$philHealth = htmlspecialchars(strip_tags(stripslashes(trim($_POST['philHealth']))));
		$pag_ibig = htmlspecialchars(strip_tags(stripslashes(trim($_POST['pag_ibig']))));
		$designation = htmlspecialchars(strip_tags(stripslashes(trim($_POST['designation']))));
		$department = htmlspecialchars(strip_tags(stripslashes(trim($_POST['department_id']))));
		$date_hire = htmlspecialchars(strip_tags(stripslashes(trim($_POST['date_hire']))));
		$username = htmlspecialchars(strip_tags(stripslashes(trim($_POST['username']))));
		$password = htmlspecialchars(strip_tags(stripslashes(trim($_POST['password']))));
		$emp_status = htmlspecialchars(strip_tags(stripslashes(trim($_POST['emp_status']))));
		$emp_id = htmlspecialchars(strip_tags(stripslashes(trim($_POST['emp_id']))));

	
		$conn->edit_employee($empid_no, $first_name, $middle_name, $last_name, $date_ofbirth, $contact_number, $complete_address, $gender, $email, $daily_rate, $mothly_rate, $sss_no, $philHealth, $pag_ibig, $designation, $department, $date_hire, $username, $password, $emp_status, $emp_id);

	}

?>

