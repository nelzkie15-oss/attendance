<?php
  require_once "../DTR_class.php";

	if(ISSET($_POST)){
		$conn = new Attendance();

		$emp_id = htmlspecialchars(strip_tags(stripslashes(trim($_POST['emp_id']))));
		$sched_from = htmlspecialchars(strip_tags(stripslashes(trim($_POST['sched_from']))));
		$sched_to = htmlspecialchars(strip_tags(stripslashes(trim($_POST['sched_to']))));
	
		$conn->add_schedule($emp_id, $sched_from, $sched_to);

	}

?>

