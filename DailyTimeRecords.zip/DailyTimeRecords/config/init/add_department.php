<?php
  require_once "../DTR_class.php";

	if(ISSET($_POST)){
		$conn = new Attendance();

		$department_name = htmlspecialchars(strip_tags(stripslashes(trim($_POST['department_name']))));
		$department_description = htmlspecialchars(strip_tags(stripslashes(trim($_POST['department_description']))));
	
		$conn->add_department($department_name, $department_description);

	}

?>

