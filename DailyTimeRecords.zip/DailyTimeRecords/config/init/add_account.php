<?php
  require_once "../StudentMonitoring_class.php";

	if(ISSET($_POST)){
		$conn = new Database();

		$full_name = htmlspecialchars(strip_tags(stripslashes(trim($_POST['full_name']))));
		$username = htmlspecialchars(strip_tags(stripslashes(trim($_POST['username']))));
		$password = htmlspecialchars(strip_tags(stripslashes(trim($_POST['password']))));
	
		$add = $conn->add_account($full_name, $username, $password);
		if($add == TRUE){
		      echo '<div class="alert alert-success">Add Account Successfully!</div><script> setTimeout(function() {  location.replace("manage_account.php"); }, 1000); </script>';
		    

		  }else{
		    echo '<div class="alert alert-danger">Add Account Failed!</div><script> setTimeout(function() {  location.replace("manage_account.php"); }, 1000); </script>';

	
		}
	}

?>

