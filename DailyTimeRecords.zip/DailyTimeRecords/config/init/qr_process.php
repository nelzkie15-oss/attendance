<?php

  require_once "../../config/DTR_class.php";
  if(ISSET($_POST)){
    $conn = new Attendance();
    $emp = htmlspecialchars(strip_tags(stripslashes(trim($_POST['qr_scan']))));

    $conn->scan_qrcode($emp);

  }

?>

