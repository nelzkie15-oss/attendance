
<?php
  require_once "../../config/DTR_class.php";
  if(isset($_POST['emp_id'])){ 	
 	 $conn = new Attendance();
	 $id = htmlspecialchars(strip_tags(stripslashes(trim($_POST['emp_id']))));
	 $conn->EmpAttendance_row($id);
		
	}

?>

