
<?php
  require_once "../../config/DTR_class.php";
  if(isset($_POST['schedule_id'])){ 	
 	 $conn = new Attendance();
	 $id = htmlspecialchars(strip_tags(stripslashes(trim($_POST['schedule_id']))));
	 $conn->dschedule_row($id);
		
	}

?>

