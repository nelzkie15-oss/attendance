<?php
  require_once "../DTR_class.php";
  include('../../libs/phpqrcode/qrlib.php'); 
  $pathDir = '../../qrcode_images/';

   //Load Composer's autoloader
    require '../../vendor/autoload.php';
	if(ISSET($_POST)){
		$conn = new Attendance();

		$image = addslashes(file_get_contents($_FILES['images']['tmp_name']));
        $emp_pic ="../uploads/". addslashes($_FILES['images']['name']);
        $image_size = getimagesize($_FILES['images']['tmp_name']);
        move_uploaded_file($_FILES["images"]["tmp_name"], $_SERVER['DOCUMENT_ROOT']."/DailyTimeRecords/uploads/" .   addslashes($_FILES["images"]["name"]));
        $empid_no = htmlspecialchars(strip_tags(stripslashes(trim($_POST['empid_no']))));
		$first_name = htmlspecialchars(strip_tags(stripslashes(trim(ucfirst($_POST['first_name'])))));
		$middle_name = htmlspecialchars(strip_tags(stripslashes(trim(ucfirst($_POST['middle_name'])))));
		$last_name = htmlspecialchars(strip_tags(stripslashes(trim(ucfirst($_POST['last_name'])))));
		$date_ofbirth = htmlspecialchars(strip_tags(stripslashes(trim($_POST['date_ofbirth']))));
		$contact_number = htmlspecialchars(strip_tags(stripslashes(trim($_POST['contact_number']))));
		$complete_address = htmlspecialchars(strip_tags(stripslashes(trim(ucfirst($_POST['complete_address'])))));
		$gender = htmlspecialchars(strip_tags(stripslashes(trim($_POST['gender']))));
		$email = htmlspecialchars(strip_tags(stripslashes(trim($_POST['email']))));
		$daily_rate = htmlspecialchars(strip_tags(stripslashes(trim($_POST['daily_rate']))));
		$mothly_rate = htmlspecialchars(strip_tags(stripslashes(trim($_POST['mothly_rate']))));
		$sss_no = htmlspecialchars(strip_tags(stripslashes(trim($_POST['sss_no']))));
		$philHealth = htmlspecialchars(strip_tags(stripslashes(trim($_POST['philHealth']))));
		$pag_ibig = htmlspecialchars(strip_tags(stripslashes(trim($_POST['pag_ibig']))));
		$designation = htmlspecialchars(strip_tags(stripslashes(trim($_POST['designation']))));
		$department = htmlspecialchars(strip_tags(stripslashes(trim($_POST['department_id']))));
		$date_hire = htmlspecialchars(strip_tags(stripslashes(trim($_POST['date_hire']))));
		$username = htmlspecialchars(strip_tags(stripslashes(trim($_POST['username']))));
		$password = htmlspecialchars(strip_tags(stripslashes(trim($_POST['password']))));
		$emp_status = htmlspecialchars(strip_tags(stripslashes(trim($_POST['emp_status']))));

		 function rand_string( $length ) {
		    $chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
		    return substr(str_shuffle($chars),0,$length);
	    }
        $codeContents = ''.rand_string(8); 
        QRcode::png($codeContents, $pathDir.''.$empid_no.'.png', QR_ECLEVEL_L, 5);

	
		$conn->add_employee($emp_pic, $empid_no, $first_name, $middle_name, $last_name, $date_ofbirth, $contact_number, $complete_address, $gender, $email, $daily_rate, $mothly_rate, $sss_no, $philHealth, $pag_ibig, $designation, $department, $date_hire, $username, $password, $emp_status, $codeContents);

	}

?>

