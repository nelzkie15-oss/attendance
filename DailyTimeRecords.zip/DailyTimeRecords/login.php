<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

    <title>Student Monitoring System</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Teko:wght@300&display=swap');
    </style>
</head>

<body>

    <nav class="navbar navbar-expand-lg navbar-light btn-light" style="border-bottom: 2px solid #7c0040">
        <div class="container">
            <a class="navbar-brand" href="#" style="font-family: 'Teko';font-size:2.2rem"> <img src="assets/images/PNG_LOGO.png" height="5%" width="5%"> Student Monitoring System</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav mr-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php" style="font-family: 'Teko';font-size:2.2rem">Home</a>
                    </li>
                </ul>

            </div>
        </div>
    </nav>
    <div class="container" style="font-family: 'Teko';font-size: 135%;">
        <div class="container px-lg-5 mt-4">
            <div class="row mx-lg-n5">
                <div class="col py-3 px-lg-5 border bg-light">

                    <CENTER>
                        <img src="assets/images/PNG_LOGO.png" height="70%" width="70%"><Br>
                        <h1> St. Mary Magdalene Monitoring System</h1>
                    </CENTER>
                </div>
                <div class="col py-3 px-lg-5 border bg-light">

                    <div class="login-box">
                        <div class="card">
                            <div class="card-header text-center" style="font-family: 'Teko';font-size: 135%;">
                                Login Here</h3>
                            </div>
                            <div class="card-body">
                                <form role="form" id="logform">
                                    <div class="">
                                        <center><span id="myalert2"></span></center>
                                    </div>
                                    <div id="myalert" style="display:none;">

                                        <div class="">
                                           <center><span id="alerttext"></span></center>
                                        </div>


                                    </div>
                                    <div id="myalert3" style="display:none;">
                                        <div class="">
                                            <div class="alert alert-success" id="alerttext3">

                                            </div>

                                        </div>
                                    </div>

                                    <div class="input-group mb-3">
                                        <input type="text" class="form-control" name="username" id="username" placeholder="Username" autocomplete="off" required="">
                                        <div class="input-group-append">
                                            <div class="input-group-text">
                                                <span class="fa fa-user"></span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="input-group mb-3">
                                        <input type="password" class="form-control" name="password" id="password" placeholder="Password" autocomplete="off" required="">
                                        <div class="input-group-append">
                                            <div class="input-group-text">
                                                <span class="fa fa-lock"></span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="input-group mb-3">
                                        <select id="type" name="type" class="form-control">
                                            <option selected>&larr; Please Select User Roles &rarr;</option>
                                            <option value="Administrator">Administrator</option>
                                            <option value="Class Teacher">Class Teacher</option>
                                        </select>
                                    </div>
                                    <div class="row">
                                        <div class="col-8">
                                            <div class="icheck-primary">
                                                <input type="checkbox" id="remember" onclick="myFunction()">
                                                <label for="remember">
                                                    Show Password
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-12 mb-1">
                                            <button type="button" id="login-button" class="btn btn-block" style="background-color: #7c0040;color: #fff">Sign In</button>
                                        </div>
                                    </div>
                                </form>

                                <p class="mb-1">
                                    <a href="forgot-password.php">I forgot my password</a>
                                </p>

                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <script>
        function myFunction() {
            var x = document.getElementById("password");
            if (x.type === "password") {
                x.type = "text";
            } else {
                x.type = "password";
            }
        }
    </script>
    <script type="text/javascript" src="assets/custom/js/login.js"> </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-Fy6S3B9q64WdZWQUiU+q4/2Lc9npb8tCaSX9FK7E8HnRr0Jz8D6OP9dO5Vg3Q9ct" crossorigin="anonymous"></script>

</body>

</html>