-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 02, 2022 at 02:10 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 7.3.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `studentmonitoring_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_account`
--

CREATE TABLE `tbl_account` (
  `account_id` int(11) NOT NULL,
  `full_name` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `type` text DEFAULT NULL,
  `status` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_account`
--

INSERT INTO `tbl_account` (`account_id`, `full_name`, `username`, `password`, `type`, `status`) VALUES
(1, 'Administrator Administrator', 'admin', 'admin@123', 'Administrator', 'Active'),
(2, 'Junil Toledo', 'nel', 'nel@123', 'Administrator', 'Inactive');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_attendance`
--

CREATE TABLE `tbl_attendance` (
  `attendance_id` int(11) NOT NULL,
  `images` text DEFAULT NULL,
  `fullname` varchar(255) DEFAULT NULL,
  `gradelevels_name` text DEFAULT NULL,
  `section_name` text DEFAULT NULL,
  `qr_code` text DEFAULT NULL,
  `student_id` int(11) DEFAULT NULL,
  `gradelevels_id` int(11) DEFAULT NULL,
  `section_id` int(11) DEFAULT NULL,
  `time_in` text DEFAULT NULL,
  `time_out` text DEFAULT NULL,
  `logdate` text DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `stud_stat` text DEFAULT NULL,
  `teacher_id` int(11) DEFAULT NULL,
  `msg_attendance` text DEFAULT NULL,
  `date_created` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_attendance`
--

INSERT INTO `tbl_attendance` (`attendance_id`, `images`, `fullname`, `gradelevels_name`, `section_name`, `qr_code`, `student_id`, `gradelevels_id`, `section_id`, `time_in`, `time_out`, `logdate`, `status`, `stud_stat`, `teacher_id`, `msg_attendance`, `date_created`) VALUES
(1, '../uploads/avatar5.png', 'Zedrick R Fabros', 'Eight', 'S2', 'Ok9Bxmp1', NULL, NULL, NULL, '06:31:PM', '06:33:PM', '2022-10-02', 1, 'Present', 2, 'Good day mrs/mr lolo your son/daughter Zedrick R Fabros is now at school campus.', NULL),
(2, '../uploads/1546373_491703094271423_8972686_n.jpg', 'Emil L Nario', 'Seven', 'S1', 'MHnm968s', NULL, NULL, NULL, '06:44:PM', NULL, '2022-10-02', 0, 'Late', 1, 'Good day mrs/mr Tita your son/daughter Emil L Nario is now at school campus.', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_gradelevels`
--

CREATE TABLE `tbl_gradelevels` (
  `gradelevels_id` int(11) NOT NULL,
  `gradelevels_name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_gradelevels`
--

INSERT INTO `tbl_gradelevels` (`gradelevels_id`, `gradelevels_name`) VALUES
(1, 'Seven'),
(2, 'Eight'),
(3, 'Nine');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_message`
--

CREATE TABLE `tbl_message` (
  `message_id` int(11) NOT NULL,
  `guardian_number` varchar(11) DEFAULT NULL,
  `message` varchar(500) DEFAULT NULL,
  `status` text DEFAULT NULL,
  `date_created` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_section`
--

CREATE TABLE `tbl_section` (
  `section_id` int(11) NOT NULL,
  `gradelevels_id` int(11) NOT NULL,
  `section_name` varchar(255) NOT NULL,
  `isAssigned` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_section`
--

INSERT INTO `tbl_section` (`section_id`, `gradelevels_id`, `section_name`, `isAssigned`) VALUES
(1, 1, 'S1', 'UnAssigned'),
(2, 2, 'S2', 'UnAssigned'),
(3, 3, 'S3', 'Assigned');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_sessionandterm`
--

CREATE TABLE `tbl_sessionandterm` (
  `sessionAndterm_id` int(11) NOT NULL,
  `session_name` varchar(255) DEFAULT NULL,
  `term_year` varchar(255) DEFAULT NULL,
  `status` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_sessionandterm`
--

INSERT INTO `tbl_sessionandterm` (`sessionAndterm_id`, `session_name`, `term_year`, `status`) VALUES
(1, 'First', '2022-2023', 'Active'),
(2, 'Second', '2023-2024', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_student`
--

CREATE TABLE `tbl_student` (
  `student_id` int(11) NOT NULL,
  `images` text DEFAULT NULL,
  `student_no` text DEFAULT NULL,
  `first_name` varchar(255) NOT NULL,
  `middle_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `email` text DEFAULT NULL,
  `contact_number` text DEFAULT NULL,
  `guardian` varchar(255) DEFAULT NULL,
  `guardian_contact` varchar(11) DEFAULT NULL,
  `gender` text DEFAULT NULL,
  `gradelevels_id` int(11) DEFAULT NULL,
  `section_id` int(11) DEFAULT NULL,
  `teacher_id` int(11) DEFAULT NULL,
  `status` text DEFAULT NULL,
  `qr_code` varchar(500) DEFAULT NULL,
  `date_created` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_student`
--

INSERT INTO `tbl_student` (`student_id`, `images`, `student_no`, `first_name`, `middle_name`, `last_name`, `email`, `contact_number`, `guardian`, `guardian_contact`, `gender`, `gradelevels_id`, `section_id`, `teacher_id`, `status`, `qr_code`, `date_created`) VALUES
(1, '../uploads/1546373_491703094271423_8972686_n.jpg', 'SM1004', 'Emil', 'L', 'Nario', 'nario@gmail.com', '09887876867', 'tita', '09756757657', 'Male', 1, 1, 1, 'Inactive', 'MHnm968s', NULL),
(2, '../uploads/avatar5.png', 'SM2007', 'Zedrick', 'R', 'Fabros', 'zed@gmail.com', '09677687888', 'lolo', '09575676767', 'Male', 2, 2, 2, 'Active', 'Ok9Bxmp1', NULL),
(3, '../uploads/avatar4.png', 'RT4555', 'Test2', 'E', 'Test2', 'test@gmail.com', '09787876878', 'lola', '09454355555', 'Male', 1, 1, 2, 'Inactive', 'cPCJxe5Q', NULL),
(4, '../uploads/110-1102775_download-empty-profile-hd-png-download.png', 'TR4554', 'John', 'A', 'Doe', NULL, '09798779899', 'papa', '09423444444', 'Male', 1, 3, 2, 'Inactive', 'jdD798e1', NULL),
(5, '../uploads/angob.png', 'RM0044', 'John', 'A', 'Doe', NULL, '09898797977', 'mama', '09543543535', 'Male', 1, 1, 3, 'Active', 'Hepjg3tG', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_teacher`
--

CREATE TABLE `tbl_teacher` (
  `teacher_id` int(11) NOT NULL,
  `images` text DEFAULT NULL,
  `first_name` varchar(255) NOT NULL,
  `middle_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `email` text DEFAULT NULL,
  `contact_number` text DEFAULT NULL,
  `gender` text DEFAULT NULL,
  `username` varchar(100) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `gradelevels_id` int(11) DEFAULT NULL,
  `section_id` int(11) DEFAULT NULL,
  `type` text DEFAULT NULL,
  `status` text DEFAULT NULL,
  `security_question` varchar(255) DEFAULT NULL,
  `answer` varchar(500) DEFAULT NULL,
  `stat_squestions` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_teacher`
--

INSERT INTO `tbl_teacher` (`teacher_id`, `images`, `first_name`, `middle_name`, `last_name`, `email`, `contact_number`, `gender`, `username`, `password`, `gradelevels_id`, `section_id`, `type`, `status`, `security_question`, `answer`, `stat_squestions`) VALUES
(1, NULL, 'Junil', 'A', 'Toledo', 'nel@gmail.com', '09787686877', 'Male', 'nel', 'nel', 1, 1, 'Class Teacher', 'Active', 'In what city were you born?', 'masbate', 1),
(2, NULL, 'Jonalyn', 'R', 'Areglo', 'jona06@gmail.com', '09776868788', 'Female', 'jona', 'jona@123', 2, 2, 'Class Teacher', 'Inactive', NULL, NULL, 0),
(3, NULL, 'Maria', 'O', 'Toledo', 'maria@gmail.com', '09675677777', 'Female', 'maria', '12345', 2, 3, 'Class Teacher', 'Active', NULL, NULL, 0),
(4, NULL, 'Test1', 'R', 'Test', 'sample@gmail.com', '09897978998', 'Male', 'test', 'test', 2, 1, 'Class Teacher', 'Inactive', NULL, NULL, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_account`
--
ALTER TABLE `tbl_account`
  ADD PRIMARY KEY (`account_id`);

--
-- Indexes for table `tbl_attendance`
--
ALTER TABLE `tbl_attendance`
  ADD PRIMARY KEY (`attendance_id`);

--
-- Indexes for table `tbl_gradelevels`
--
ALTER TABLE `tbl_gradelevels`
  ADD PRIMARY KEY (`gradelevels_id`);

--
-- Indexes for table `tbl_message`
--
ALTER TABLE `tbl_message`
  ADD PRIMARY KEY (`message_id`);

--
-- Indexes for table `tbl_section`
--
ALTER TABLE `tbl_section`
  ADD PRIMARY KEY (`section_id`);

--
-- Indexes for table `tbl_sessionandterm`
--
ALTER TABLE `tbl_sessionandterm`
  ADD PRIMARY KEY (`sessionAndterm_id`);

--
-- Indexes for table `tbl_student`
--
ALTER TABLE `tbl_student`
  ADD PRIMARY KEY (`student_id`);

--
-- Indexes for table `tbl_teacher`
--
ALTER TABLE `tbl_teacher`
  ADD PRIMARY KEY (`teacher_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_account`
--
ALTER TABLE `tbl_account`
  MODIFY `account_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_attendance`
--
ALTER TABLE `tbl_attendance`
  MODIFY `attendance_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_gradelevels`
--
ALTER TABLE `tbl_gradelevels`
  MODIFY `gradelevels_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_message`
--
ALTER TABLE `tbl_message`
  MODIFY `message_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_section`
--
ALTER TABLE `tbl_section`
  MODIFY `section_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_sessionandterm`
--
ALTER TABLE `tbl_sessionandterm`
  MODIFY `sessionAndterm_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_student`
--
ALTER TABLE `tbl_student`
  MODIFY `student_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbl_teacher`
--
ALTER TABLE `tbl_teacher`
  MODIFY `teacher_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
